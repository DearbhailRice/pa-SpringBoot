/**
 * 
 */
package board;


import java.util.HashMap;
import java.util.Map;

/**
 * @author dearb
 *
 */
public class Board  {
	
	//private static final boolean Ownership = false;
	
	
	private static Map<Integer, Square> board = new HashMap<Integer, Square>();
	private static Map<Integer,Area> admin= new HashMap<Integer, Area>();
	private static Map<Integer,Area> testAndDesign = new HashMap<Integer, Area>();
	private static Map<Integer,Area> dev = new HashMap<Integer, Area>();
	private static Map<Integer,Area>programming = new HashMap<Integer, Area>();
	
	
	public static void main (String [] args) {
		
		
		//creating go square 
		
		GoSquare Go = new GoSquare ("Go", Type.Go,1,50,false); 
		
		
		// creating Area Squares 
		
		/**public Area(String name, Type type, int position,int value, int propertyValue, int baseRent, int poorEmployeeCost,
		int poorEmployeeRent, int mediocoreEmployeeCost, int mediocoreEmployeeRent, int goodEmployeeCost,
		int goodEmployeeRent, int exceptionalEmployeeCost, int exceptionalEmployeeRent) {*/
		Area A1 = new Area ("Customer Service", Type.ADMIN, 3,50, true,50,25,20, 10, 30, 20, 40, 30,50 ,40);
		Area A2 = new Area("Database Management",Type.ADMIN,4,60,true,60,30,40,30,50,40,50,50,70,60);
		Area T1 = new Area("Graphic Design", Type.TESTING_AND_DESIGN,6,70,true,70,35,30,20,40,30,50,40,60,50);
		Area T2 = new Area("User Interaction", Type.TESTING_AND_DESIGN, 7,70,true,70,25,20,10,30,20,40,30,50,40);
		Area T3 = new Area("Software Testing",Type.TESTING_AND_DESIGN, 8,100,true,100,50,70,60,80,70,90,80,100,90);
		Area D1 = new Area("Web Development",Type.DEVELOPMENT,10,80,true,80,40,60,50,70,60,80,70,90,80);
		Area D2 = new Area("Software Engineering",Type.DEVELOPMENT, 11,120,true,120,60,70,60,80,70,90,80,100,90);
		Area P1 = new Area("Java Skills", Type.PROGRAMMING, 14,60,true,60,30, 50,40,60,50,70,60,80, 70);
		Area P2 = new Area("Python Skills", Type.PROGRAMMING, 15,40,true,40,20,40,30,50,40,60,50,70,60);
		Area P3 = new Area("C++ Skills", Type.PROGRAMMING, 16,50,true,50,25,40,30,50,40,60,50,70,60);
		
		// re do into for loops to add types into arrays (using if statements)
		
		admin.put(3,A1);
		admin.put(4,A2);
		
		
		testAndDesign.put(6,T1);
		testAndDesign.put(7,T2);
		testAndDesign.put(8,T3);
		
	
		dev.put(10,D1);
		dev.put(11,D2);
		
		
		programming.put(14,P1);
		programming.put(15,P2);
		programming.put(16,P3);
		
		/**
		 * String name, Type type, int position , boolean goToJail
		 */
		mscSquare j1 = new mscSquare ("Jail", Type.Jail,9,0, false,false);
		mscSquare hold1= new mscSquare("Go To Jail", Type.Go_To_Jail,2,0,false,true);
		mscSquare hold2= new mscSquare("Free_Parking", Type.Free_Parking,5,0,false,false);
		mscSquare hold3= new mscSquare("Chance", Type.Chance,12,0,false,false);
		mscSquare hold4= new mscSquare("Free_Parking", Type.Free_Parking,13,0,false,false);
		
		
		//assign to Map board
		board.put(1, Go);
		board.put(2, hold1);
		board.put(3, A1);
		board.put(4, A2);
		board.put(5,hold2 );
		board.put(6,T1 );
		board.put(7,T2 );
		board.put(8,T3 );
		board.put(9,j1 );
		board.put(10,D1 );
		board.put(11,D2 );
		board.put(12,hold3 );
		board.put(13,hold4 );
		board.put(14,P1 );
		board.put(15,P2 );
		board.put(16, P3);
		
		
		
	
		
		returnBoard();
		returnAdmin();
		returnDev();
		returnProgramming();
		returnTestAndDesign();
	}
	
	/**
	 * method to give access to board array in other classes 
	 * @return
	 */
	public static Map<Integer, Square> returnBoard() {
		return board;
	}
		
	public static Map<Integer,Area>returnAdmin(){
		return admin;
	}
	
	public static Map<Integer,Area> returnTestAndDesign(){
		return testAndDesign;
	}
	
	public static Map<Integer,Area>returnDev(){
		return dev;
	}
	public static Map<Integer,Area>returnProgramming(){
		return programming;
	}
	
	
}
