/**
 * 
 */
package board;

/**
 * @author dearb
 *
 */
public enum Type {
	 Go,Go_To_Jail, Jail, Free_Parking, Chance, ADMIN, TESTING_AND_DESIGN, DEVELOPMENT, PROGRAMMING;

}
