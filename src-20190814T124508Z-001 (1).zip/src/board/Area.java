/**
 * 
 */
package board;

import player.Player;

/**
 * @author dearb
 *
 */
public class Area extends Square {

	private int propertyValue;
	private int baseRent;
	private int poorEmployeeCost;
	private int poorEmployeeRent;
	private int mediocoreEmployeeCost;
	private int mediocoreEmployeeRent;
	private int goodEmployeeCost;
	private int goodEmployeeRent;
	private int exceptionalEmployeeCost;
	private int exceptionalEmployeeRent;
	private Player owner;
	private boolean hasOwner;
	private boolean ownPooremployees;
	private boolean ownMediocoreemployees;
	private boolean ownGoodemployees;
	private boolean ownExceptionalemployees;

	/**
	 * default constructor
	 */
	public Area() {

	}

	/**
	 * constructor without booleans
	 * 
	 * @param name
	 * @param type
	 * @param position
	 * @param value
	 * @param propertyValue
	 * @param baseRent
	 * @param poorEmployeeCost
	 * @param poorEmployeeRent
	 * @param mediocoreEmployeeCost
	 * @param mediocoreEmployeeRent
	 * @param goodEmployeeCost
	 * @param goodEmployeeRent
	 * @param exceptionalEmployeeCost
	 * @param exceptionalEmployeeRent
	 */
	public Area(String name, Type type, int position, int value, boolean purchase, int propertyValue, int baseRent,
			int poorEmployeeCost, int poorEmployeeRent, int mediocoreEmployeeCost, int mediocoreEmployeeRent,
			int goodEmployeeCost, int goodEmployeeRent, int exceptionalEmployeeCost, int exceptionalEmployeeRent) {

		super(name, type, position, value, purchase);
		this.setPropertyValue(propertyValue);
		this.setBaseRent(baseRent);
		this.setPoorEmployeeCost(poorEmployeeCost);
		this.setPoorEmployeeRent(poorEmployeeRent);
		this.setMediocoreEmployeeCost(mediocoreEmployeeCost);
		this.setMediocoreEmployeeRent(mediocoreEmployeeRent);
		this.setGoodEmployeeCost(goodEmployeeCost);
		this.setGoodEmployeeRent(goodEmployeeRent); 
		this.setExceptionalEmployeeCost(exceptionalEmployeeCost);
		this.setExceptionalEmployeeRent(exceptionalEmployeeRent);

	}

	/**
	 * constructor with all args
	 * 
	 * @param name
	 * @param type
	 * @param position
	 * @param propertyValue
	 * @param baseRent
	 * @param poorEmployeeCost
	 * @param poorEmployeeRent
	 * @param mediocoreEmployeeCost
	 * @param mediocoreEmployeeRent
	 * @param goodEmployeeCost
	 * @param goodEmployeeRent
	 * @param exceptionalEmployeeCost
	 * @param exceptionalEmployeeRent
	 * @param owner
	 * @param ownPooremployees
	 * @param ownMediocoreemployees
	 * @param ownGoodemployees
	 * @param ownExceptionalemployees
	 */
	public Area(String name, Type type, int position, int value, boolean purchase, int propertyValue, int baseRent,
			int poorEmployeeCost, int poorEmployeeRent, int mediocoreEmployeeCost, int mediocoreEmployeeRent,
			int goodEmployeeCost, int goodEmployeeRent, int exceptionalEmployeeCost, int exceptionalEmployeeRent,
			Player owner, boolean hasOwner, boolean ownPooremployees, boolean ownMediocoreemployees,
			boolean ownGoodemployees, boolean ownExceptionalemployees) {
		super(name, type, position, value, purchase);
		this.setPropertyValue(propertyValue);
		this.setBaseRent(baseRent);
		this.setPoorEmployeeCost(poorEmployeeCost);
		this.setPoorEmployeeRent(poorEmployeeRent);
		this.setMediocoreEmployeeCost(mediocoreEmployeeCost);
		this.setMediocoreEmployeeRent(mediocoreEmployeeRent);
		this.setGoodEmployeeCost(goodEmployeeCost);
		this.setGoodEmployeeRent(goodEmployeeRent); 
		this.setExceptionalEmployeeCost(exceptionalEmployeeCost);
		this.setExceptionalEmployeeRent(exceptionalEmployeeRent);
		this.owner = owner;
		this.ownPooremployees = ownPooremployees;
		this.ownMediocoreemployees = ownMediocoreemployees;
		this.ownGoodemployees = ownGoodemployees;
		this.ownExceptionalemployees = ownExceptionalemployees;
		this.hasOwner = hasOwner;
	}

	/**
	 * @return the propertyValue
	 */
	public int getPropertyValue() {
		return propertyValue;
	}

	/**
	 * @param propertyValue the propertyValue to set
	 */
	public void setPropertyValue(int propertyValue) {
		if (propertyValue>=0) {
		this.propertyValue = propertyValue;
		}else {
			throw new IllegalArgumentException();
		}
	}

	/**
	 * @return the baseRent
	 */
	public int getBaseRent() {
		return baseRent;
	}

	/**
	 * @param baseRent the baseRent to set
	 */
	public void setBaseRent(int baseRent) {
		if ((baseRent>0)&&(baseRent<= 200)) {
			this.baseRent = baseRent;
		}else {
			throw new IllegalArgumentException();
		}
		
	}

	/**
	 * @return the poorEmployeeCost
	 */
	public int getPoorEmployeeCost() {
		
		return poorEmployeeCost;
	}

	/**
	 * @param poorEmployeeCost the poorEmployeeCost to set
	 */
	public void setPoorEmployeeCost(int poorEmployeeCost) {
		if ((poorEmployeeCost>0)&&(poorEmployeeCost<= 200)) {
			this.poorEmployeeCost = poorEmployeeCost;
		}else {
			throw new IllegalArgumentException();
		}
		
	}

	/**
	 * @return the poorEmployeeRent
	 */
	public int getPoorEmployeeRent() {
		return poorEmployeeRent;
	}

	/**
	 * @param poorEmployeeRent the poorEmployeeRent to set
	 */
	public void setPoorEmployeeRent(int poorEmployeeRent) {
		if ((poorEmployeeRent>0)&&(poorEmployeeRent<=200)) {
		this.poorEmployeeRent = poorEmployeeRent;
		}else{
			throw new IllegalArgumentException();
		}
	}

	/**
	 * @return the mediocoreEmployeeCost
	 */
	public int getMediocoreEmployeeCost() {
		return mediocoreEmployeeCost;
	}

	/**
	 * @param mediocoreEmployeeCost the mediocoreEmployeeCost to set
	 */
	public void setMediocoreEmployeeCost(int mediocoreEmployeeCost) {
		if((mediocoreEmployeeCost>0)&&(mediocoreEmployeeCost<=200)) {
		this.mediocoreEmployeeCost = mediocoreEmployeeCost;
		}else {
			throw new IllegalArgumentException();
		}
	}

	/**
	 * @return the mediocoreEmployeeRent
	 */
	public int getMediocoreEmployeeRent() {
		return mediocoreEmployeeRent;
	}

	/**
	 * @param mediocoreEmployeeRent the mediocoreEmployeeRent to set
	 */
	public void setMediocoreEmployeeRent(int mediocoreEmployeeRent) throws IllegalArgumentException {
		if ((mediocoreEmployeeRent>0)&&(mediocoreEmployeeRent<=200)) {
		this.mediocoreEmployeeRent = mediocoreEmployeeRent;
		}else {
			throw new IllegalArgumentException();
		}
	}

	/**
	 * @throw new IllegalArgumentException();urn the goodEmployeeCost
	 */
	public int getGoodEmployeeCost() {
		return goodEmployeeCost;
	}

	/**
	 * @param goodEmployeeCost the goodEmployeeCost to set
	 */
	public void setGoodEmployeeCost(int goodEmployeeCost)throws IllegalArgumentException {
		if ((goodEmployeeCost>0)&&(goodEmployeeCost<=200)) {
		this.goodEmployeeCost = goodEmployeeCost;
		}else {
			throw new IllegalArgumentException();
		}
	}

	/**
	 * @return the goodEmployeeRent
	 */
	public int getGoodEmployeeRent() {
		return goodEmployeeRent;
	}

	/**
	 * @param goodEmployeeRent the goodEmployeeRent to set
	 */
	public void setGoodEmployeeRent(int goodEmployeeRent) throws IllegalArgumentException {
		if((goodEmployeeRent>0)&&(goodEmployeeRent<=200)) {
		this.goodEmployeeRent = goodEmployeeRent;
		}else {
			throw new IllegalArgumentException();
		}
	}

	/**
	 * @return the exceptionalEmployeeCost
	 */
	public int getExceptionalEmployeeCost() {
		return exceptionalEmployeeCost;
	}

	/**
	 * @param exceptionalEmployeeCost the exceptionalEmployeeCost to set
	 */
	public void setExceptionalEmployeeCost(int exceptionalEmployeeCost) throws IllegalArgumentException {
		if((exceptionalEmployeeCost>0)&&(exceptionalEmployeeCost<=200)) {
		this.exceptionalEmployeeCost = exceptionalEmployeeCost;
		}else {
			throw new IllegalArgumentException();
		}
	}

	/**
	 * @return the exceptionalEmployeeRent
	 */
	public int getExceptionalEmployeeRent() {
		return exceptionalEmployeeRent;
	}

	/**
	 * @param exceptionalEmployeeRent the exceptionalEmployeeRent to set
	 */
	public void setExceptionalEmployeeRent(int exceptionalEmployeeRent) throws IllegalArgumentException {
		if((exceptionalEmployeeRent>0)&&(exceptionalEmployeeRent<=200)) {
			this.exceptionalEmployeeRent = exceptionalEmployeeRent;
			}else {
				 throw new IllegalArgumentException();
			}
	}

	/**
	 * @return the owner
	 */
	public Player getOwner() {
		return owner;
	}

	/**
	 * @param owner the owner to set
	 */
	public void setOwner(Player owner) {
		this.owner = owner;
	}

	/**
	 * @return the ownPooremployees
	 */
	public boolean isOwnPooremployees() {
		return ownPooremployees;
	}

	/**
	 * @param ownPooremployees the ownPooremployees to set
	 */
	public void setOwnPooremployees(boolean ownPooremployees) {
		this.ownPooremployees = ownPooremployees;
	}

	/**
	 * @return the ownMediocoreemployees
	 */
	public boolean isOwnMediocoreemployees() {
		return ownMediocoreemployees;
	}

	/**
	 * @param ownMediocoreemployees the ownMediocoreemployees to set
	 */
	public void setOwnMediocoreemployees(boolean ownMediocoreemployees) {
		this.ownMediocoreemployees = ownMediocoreemployees;
	}

	/**
	 * @return the ownGoodemployees
	 */
	public boolean isOwnGoodemployees() {
		return ownGoodemployees;
	}

	/**
	 * @param ownGoodemployees the ownGoodemployees to set
	 */
	public void setOwnGoodemployees(boolean ownGoodemployees) {
		this.ownGoodemployees = ownGoodemployees;
	}

	/**
	 * @return the ownExceptionalemployees
	 */
	public boolean isOwnExceptionalemployees() {
		return ownExceptionalemployees;
	}

	/**
	 * @param ownExceptionalemployees the ownExceptionalemployees to set
	 */
	public void setOwnExceptionalemployees(boolean ownExceptionalemployees) {
		this.ownExceptionalemployees = ownExceptionalemployees;
	}

	/**
	 * @return the hasOwner
	 */
	public boolean isHasOwner() {
		return hasOwner;
	}

	/**
	 * @param hasOwner the hasOwner to set
	 */
	public void setHasOwner(boolean hasOwner) {
		this.hasOwner = hasOwner;
	}

	/**
	 * checks if any employees are owned and calculates the rent owed for a property
	 */
	public int calculateRent() {
		int rent = 0;

		// loop to check if employees and area are owned and calculate rent

		if (hasOwner) {
			rent += this.baseRent;
			
				if (ownPooremployees) {
					rent += this.poorEmployeeRent;
				} 
				if (ownMediocoreemployees) {
					rent += this.mediocoreEmployeeRent;
				} 
				if (ownGoodemployees) {
					rent += this.goodEmployeeRent;
				} 
				if (ownExceptionalemployees) {
					rent += this.exceptionalEmployeeRent;
				}
			}else {
				rent = 0;
			}

		
		return rent;
	}

	/*
	 * print information regarding the areas value and rent costs 
	 * 
	 * @see board.Square#displayAll()
	 */
	@Override
	public void displayAll() {
		// TODO Auto-generated method stub
		super.displayAll();
		
		System.out.println("Base rent : " + this.baseRent);
		System.out.println("COST OF:" + "\t poor Employees = " + this.poorEmployeeCost + "\t Mediocore Employees= "
				+ this.mediocoreEmployeeCost + "\t Good employees : " + this.goodEmployeeCost + "\t Excellent employees"
				+ this.exceptionalEmployeeCost);
		System.out.println("Rent with employees is the cost of the employees - 10 ");
		System.out.println("Rent for areas with employees is the base rent plus the value of all the employees rent  ");
	}

}