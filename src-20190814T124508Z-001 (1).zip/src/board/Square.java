/**
 * 
 */
package board;



/**
 * abstract classs as basis for the squares on the technopoly board
 * @author dearb
 *
 */
public abstract class Square  {
	private static final int max_Position_Num= 16;
	
	
	// add owner to this as boolean then set in msc as flase always 
	/**
	 * squares individual name 
	 */
	private String name; 
	
	/**
	 * squares type ie area go jail chance or free parking 
	 */
	private Type type ; 
	
	/**
	 * squares position
	 */
	private int position ;
	
	/**
	 * how much is the square worth
	 */
	private int value;
	
	/**
	 * is the square purchaseable 
	 */
	private boolean purchase;
	
	/**
	 * default constructor
	 */
	public Square () {
		
	}

	/**
	 * @param name
	 * @param type
	 * @param position
	 * @param value
	 */
	public Square(String name, Type type, int position, int value, boolean purchase) {
		super();
		this.name = name;
		this.type = type;
		this.setPosition(position);
		this.value= value;
		this.purchase= purchase;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the type
	 */
	public Type getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(Type type) {
		this.type = type;
	}

	/**
	 * @return the position
	 */
	public int getPosition() {
		return position;
	}

	/**
	 * @param position the position to set
	 */
	public void setPosition(int position) {
		if((position>0)&&(position<=max_Position_Num)){
		this.position = position;
		}else {
			System.out.println("Position error ");
			this.position=0;
		}
	}
	

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}
	

	/**
	 * @return the purchase
	 */
	public boolean isPurchase() {
		return purchase;
	}

	/**
	 * @param purchase the purchase to set
	 */
	public void setPurchase(boolean purchase) {
		this.purchase = purchase;
	}

	public  void displayAll() {
		System.out.println("Position : " +this.position);
		System.out.println("Name : "+ this.name );
		System.out.println("Value : " +this.value );
		System.out.println("Area : "+ this.type);
	}
	
	

}
