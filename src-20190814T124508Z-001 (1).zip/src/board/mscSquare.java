/**
 * 
 */
package board;

/**
 * @author dearb
 *
 */
public class mscSquare extends Square {
	private boolean goToJail;

	/**
	 * 
	 */
	public mscSquare() {
		
	}

	/**
	 * @param name
	 * @param type
	 * @param position
	 */
	public mscSquare(String name, Type type, int position ,int value,boolean purchase, boolean goToJail) {
		super(name, type, position, value, purchase);
		this.goToJail= goToJail;
		
	}

	/**
	 * @return the goToJail
	 */
	public boolean isGoToJail() {
		return goToJail;
	}

	/**
	 * @param goToJail the goToJail to set
	 */
	public void setGoToJail(boolean goToJail) {
		this.goToJail = goToJail;
	}
	
	
	
	
	
	

}
