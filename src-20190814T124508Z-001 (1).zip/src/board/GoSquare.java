/**
 * 
 */
package board;

import java.util.ArrayList;



/**
 * @author dearb
 *
 */
public class GoSquare extends Square{
	
	public static final int PASS_GO = 50;
	
	/**
	 * how much it costs/ is gained from landing on the square 
	 */
	

	/**
	 * 
	 */
	public GoSquare() {
		super();
		
	}

	/**
	 * @param name
	 * @param type
	 * @param position
	 */
	public GoSquare(String name, Type type, int position,int value, boolean purchase) {
		super(name, type, position, value, purchase);
		
	}

	

	/* (non-Javadoc)
	 * @see board.Square#displayAll()
	 */
	
	/**public void displayAll() {
		
		super.displayAll();
		System.out.println("Collect : �" +this.value);
	}
	*/
	/**
	 * Method called when player passes the go square on the board. Adds PASS_GO constant value to the player's balance
	 * @param players2
	 */
	public static void passGo(ArrayList<player.Player> players, int loop) {
		//this loop is causing the balance to print repeatedly 
		
		players.get(loop).addToBalance(PASS_GO);
			
		System.out.println("You have passed go. Collect �" +PASS_GO +" Your new balance is �" + players.get(loop).getBalance());
		
		
		
		
		
	
	}

	
}
