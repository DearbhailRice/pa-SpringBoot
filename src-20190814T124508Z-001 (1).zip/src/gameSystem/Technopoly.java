/**
 * 
 */
package gameSystem;



import java.util.Scanner;

import board.Board;
import player.PlayerManager;

/**
 * @author dearb
 *
 */
public class Technopoly {

	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner scanner = new Scanner (System.in); 
		 
		PlayerManager.main(args);
		Board.main(args);
		Turn.main(args);
		
		scanner.close();
		

	}

}
