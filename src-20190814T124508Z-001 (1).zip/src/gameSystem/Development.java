package gameSystem;

import java.util.ArrayList;
import java.util.Scanner;

import board.Board;

public class Development {

	public static void main(String[] args) {

		Board.main(args);

	}

	/**
	 * method to allow players to develop areas where they own the entire field
	 * 
	 * @param players
	 * @param landed
	 * @param loop
	 * @param scanner
	 */
	public static void developAreas(ArrayList<player.Player> players, int landed, int loop, Scanner scanner) {

		int adminPropertiesOwned = 0;
		int techDesignPropertiesOwned = 0;
		int devPropertiesOwned = 0;
		int ProgrammingPropertiesOwned = 0;
		boolean validinput = false;

		String develop;
		String hireEmployees;
		boolean correctInput = false;

		/**
		 * System.out.println("admin " + adminPropertiesOwned); System.out.println("dev"
		 * + devPropertiesOwned); System.out.println("Test" +
		 * techDesignPropertiesOwned); System.out.println(" prog " +
		 * ProgrammingPropertiesOwned);
		 */

		switch (Board.returnBoard().get(landed).getType()) {

		case ADMIN:

			for (int count = 0; count < players.get(loop).getPropertiesOwned().size(); count++) {

				if (Board.returnAdmin().containsKey(players.get(loop).getPropertiesOwned().get(count).getPosition())) {
					adminPropertiesOwned += 1;
				} else {

				}

			}

			if (adminPropertiesOwned == Board.returnAdmin().size()) {
				do {
					System.out.println(

							" You own all of the properties in the admin group, Would you like to hire staff in this area? Enter y for yet or N for no followed by the enter key ");

					develop = scanner.next();

					if (develop.equalsIgnoreCase("y")) {

						if (!(Board.returnAdmin().get(players.get(loop).getPosition()).isOwnPooremployees())
								&& !(Board.returnAdmin().get(players.get(loop).getPosition()).isOwnMediocoreemployees())
								&& !(Board.returnAdmin().get(players.get(loop).getPosition()).isOwnGoodemployees())
								&& !(Board.returnAdmin().get(players.get(loop).getPosition())
										.isOwnExceptionalemployees())) {
							System.out.println(" poor employees cost "
									+ Board.returnAdmin().get(players.get(loop).getPosition()).getPoorEmployeeCost());
							System.out.println("this increases the rent on this area to "
									+ (Board.returnAdmin().get(players.get(loop).getPosition()).calculateRent() + Board
											.returnAdmin().get(players.get(loop).getPosition()).getPoorEmployeeRent()));
							System.out.println(
									" would you like to hire poor employees to develop your area? please enter y for yes or n for no followed by the enter key");

							try {

								do {
									if (scanner.hasNext()) {
										hireEmployees = scanner.next();

										if (hireEmployees.equalsIgnoreCase("y")) {
											if (players.get(loop).getBalance() < Board.returnAdmin()
													.get(players.get(loop).getPosition()).getPoorEmployeeCost()) {
												System.out.println("insufficient funds  to pruchase employees");

											} else if (players.get(loop).getBalance() > Board.returnAdmin()
													.get(players.get(loop).getPosition()).getPoorEmployeeCost()) {

												players.get(loop).SubtractFromBalance(Board.returnAdmin()
														.get(players.get(loop).getPosition()).getPoorEmployeeCost());

												System.out.println(
														"your new balance is : " + players.get(loop).getBalance());
												Board.returnAdmin().get(players.get(loop).getPosition())
														.setOwnPooremployees(true);
												;
											}
											validinput = true;

										} else if (hireEmployees.equalsIgnoreCase("n")) {
											System.out.println("No problem ");
											validinput = true;
										} else {
											System.out.println("Please enter y or n only ");
											validinput = false;
										}
									}
								} while (!validinput);

							} catch (Exception ie) {
								System.out.println("Something went wrong ");
								developAreas(players, landed, loop, scanner);

							}

						} else if ((Board.returnAdmin().get(players.get(loop).getPosition()).isOwnPooremployees())
								&& !(Board.returnAdmin().get(players.get(loop).getPosition()).isOwnMediocoreemployees())
								&& !(Board.returnAdmin().get(players.get(loop).getPosition()).isOwnGoodemployees())
								&& !(Board.returnAdmin().get(players.get(loop).getPosition())
										.isOwnExceptionalemployees())) {
							System.out.println(" Mediocore employees cost " + Board.returnAdmin()
									.get(players.get(loop).getPosition()).getMediocoreEmployeeCost());
							System.out.println("this increases the rent on this area to "
									+ (Board.returnAdmin().get(players.get(loop).getPosition()).calculateRent()
											+ Board.returnAdmin().get(players.get(loop).getPosition())
													.getMediocoreEmployeeRent()));
							System.out.println(
									" would you like to hire Medicore employees to develop your area? please enter y for yes or n for no followed by the enter key");
							try {

								do {
									if (scanner.hasNext()) {
										hireEmployees = scanner.next();
										if (hireEmployees.equalsIgnoreCase("y")) {
											if (players.get(loop).getBalance() < Board.returnAdmin()
													.get(players.get(loop).getPosition()).getMediocoreEmployeeCost()) {
												System.out.println("insufficient funds  to pruchase employees");

											} else if (players.get(loop).getBalance() > Board.returnAdmin()
													.get(players.get(loop).getPosition()).getMediocoreEmployeeCost()) {
												players.get(loop).SubtractFromBalance(
														Board.returnAdmin().get(players.get(loop).getPosition())
																.getMediocoreEmployeeCost());
												Board.returnAdmin().get(players.get(loop).getPosition())
														.setOwnMediocoreemployees(true);
												System.out.println(
														"your new balance is : " + players.get(loop).getBalance());
											}
											validinput = true;
										} else if (hireEmployees.equalsIgnoreCase("n")) {
											System.out.println("No problem ");
											validinput = true;
										} else {
											System.out.println("Please enter y or n only ");
											validinput = false;
										}
									}
								} while (!validinput);

							} catch (Exception ie) {
								System.out.println("Something went wrong ");
								developAreas(players, landed, loop, scanner);

							}

						} else if ((Board.returnAdmin().get(players.get(loop).getPosition()).isOwnPooremployees())
								&& (Board.returnAdmin().get(players.get(loop).getPosition()).isOwnMediocoreemployees())
								&& !(Board.returnAdmin().get(players.get(loop).getPosition()).isOwnGoodemployees())
								&& !(Board.returnAdmin().get(players.get(loop).getPosition())
										.isOwnExceptionalemployees())) {
							System.out.println(" Good employees cost "
									+ Board.returnAdmin().get(players.get(loop).getPosition()).getGoodEmployeeCost());
							System.out.println("this increases the rent on this area to "
									+ (Board.returnAdmin().get(players.get(loop).getPosition()).calculateRent() + Board
											.returnAdmin().get(players.get(loop).getPosition()).getGoodEmployeeRent()));
							System.out.println(
									" would you like to hire good employees to develop your area? please enter y for yes or n for no followed by the enter key");
							try {

								do {
									if (scanner.hasNext()) {
										hireEmployees = scanner.next();
										if (hireEmployees.equalsIgnoreCase("y")) {
											if (players.get(loop).getBalance() < Board.returnAdmin()
													.get(players.get(loop).getPosition()).getGoodEmployeeCost()) {
												System.out.println("insufficient funds  to pruchase employees");

											} else if (players.get(loop).getBalance() > Board.returnAdmin()
													.get(players.get(loop).getPosition()).getGoodEmployeeCost()) {
												players.get(loop).SubtractFromBalance(Board.returnAdmin()
														.get(players.get(loop).getPosition()).getGoodEmployeeCost());
												Board.returnAdmin().get(players.get(loop).getPosition())
														.setOwnGoodemployees(true);
												System.out.println(
														"your new balance is : " + players.get(loop).getBalance());
											}
											validinput = true;
										} else if (hireEmployees.equalsIgnoreCase("n")) {
											System.out.println("No problem ");
											validinput = true;
										} else {
											System.out.println("Please enter y or n only ");
											validinput = false;
										}
									}
								} while (!validinput);

							} catch (Exception ie) {
								System.out.println("Something went wrong ");
								developAreas(players, landed, loop, scanner);

							}
						} else if ((Board.returnAdmin().get(players.get(loop).getPosition()).isOwnPooremployees())
								&& (Board.returnAdmin().get(players.get(loop).getPosition()).isOwnMediocoreemployees())
								&& (Board.returnAdmin().get(players.get(loop).getPosition()).isOwnGoodemployees())
								&& !(Board.returnAdmin().get(players.get(loop).getPosition())
										.isOwnExceptionalemployees())) {
							System.out.println(" Exceptional employees cost " + Board.returnAdmin()
									.get(players.get(loop).getPosition()).getExceptionalEmployeeCost());
							System.out.println("this increases the rent on this area to "
									+ (Board.returnAdmin().get(players.get(loop).getPosition()).calculateRent()
											+ Board.returnAdmin().get(players.get(loop).getPosition())
													.getExceptionalEmployeeRent()));
							System.out.println(
									" would you like to hire Exceptional employees to develop your area? please enter y for yes or n for no followed by the enter key");
							try {

								do {
									if (scanner.hasNext()) {
										hireEmployees = scanner.next();
										if (hireEmployees.equalsIgnoreCase("y")) {
											if (players.get(loop).getBalance() < Board.returnAdmin()
													.get(players.get(loop).getPosition())
													.getExceptionalEmployeeCost()) {
												System.out.println("insufficient funds  to pruchase employees");

											} else if (players.get(loop).getBalance() > Board.returnAdmin()
													.get(players.get(loop).getPosition())
													.getExceptionalEmployeeCost()) {
												players.get(loop).SubtractFromBalance(
														Board.returnAdmin().get(players.get(loop).getPosition())
																.getExceptionalEmployeeCost());
												Board.returnAdmin().get(players.get(loop).getPosition())
														.setOwnExceptionalemployees(true);
												System.out.println(
														"your new balance is : " + players.get(loop).getBalance());
											}
											validinput = true;
										} else if (hireEmployees.equalsIgnoreCase("n")) {
											System.out.println("No problem ");
											validinput = true;
										} else {
											System.out.println("Please enter y or n only ");
											validinput = false;
										}
									}
								} while (!validinput);

							} catch (Exception ie) {
								System.out.println("Something went wrong ");
								developAreas(players, landed, loop, scanner);

							}

						} else if ((Board.returnAdmin().get(players.get(loop).getPosition()).isOwnPooremployees())
								&& (Board.returnAdmin().get(players.get(loop).getPosition()).isOwnMediocoreemployees())
								&& (Board.returnAdmin().get(players.get(loop).getPosition()).isOwnGoodemployees())
								&& (Board.returnAdmin().get(players.get(loop).getPosition())
										.isOwnExceptionalemployees())) {
							System.out.println(
									"This area is fully developed you are recieveing the maximum rent possible");
						}
						correctInput = true;
					} else if (develop.equalsIgnoreCase("n")) {
						System.out.println("No problem");
						correctInput = true;
					} else {
						System.out.println("Please enter either y or n ");
						correctInput = false;
					}
				} while (!correctInput);
			}
			break;

		case TESTING_AND_DESIGN:
			for (int count = 0; count < players.get(loop).getPropertiesOwned().size(); count++) {

				if (Board.returnTestAndDesign()
						.containsKey(players.get(loop).getPropertiesOwned().get(count).getPosition())) {
					techDesignPropertiesOwned += 1;
				} else {

				}

			}

			if (techDesignPropertiesOwned == Board.returnTestAndDesign().size()) {
				do {
					System.out.println(

							" You own all of the properties in the admin group, Would you like to hire staff in this area? Enter y for yet or N for no followed by the enter key ");

					develop = scanner.next();

					if (develop.equalsIgnoreCase("y")) {

						if (!(Board.returnTestAndDesign().get(players.get(loop).getPosition()).isOwnPooremployees())
								&& !(Board.returnTestAndDesign().get(players.get(loop).getPosition())
										.isOwnMediocoreemployees())
								&& !(Board.returnTestAndDesign().get(players.get(loop).getPosition())
										.isOwnGoodemployees())
								&& !(Board.returnTestAndDesign().get(players.get(loop).getPosition())
										.isOwnExceptionalemployees())) {
							System.out.println(" poor employees cost " + Board.returnTestAndDesign()
									.get(players.get(loop).getPosition()).getPoorEmployeeCost());
							System.out.println("this increases the rent on this area to "
									+ (Board.returnTestAndDesign().get(players.get(loop).getPosition()).calculateRent()
											+ Board.returnTestAndDesign().get(players.get(loop).getPosition())
													.getPoorEmployeeRent()));
							System.out.println(
									" would you like to hire poor employees to develop your area? please enter y for yes or n for no followed by the enter key");

							try {

								do {
									if (scanner.hasNext()) {
										hireEmployees = scanner.next();

										if (hireEmployees.equalsIgnoreCase("y")) {
											if (players.get(loop).getBalance() < Board.returnTestAndDesign()
													.get(players.get(loop).getPosition()).getPoorEmployeeCost()) {
												System.out.println("insufficient funds  to pruchase employees");

											} else if (players.get(loop).getBalance() > Board.returnTestAndDesign()
													.get(players.get(loop).getPosition()).getPoorEmployeeCost()) {

												players.get(loop).SubtractFromBalance(Board.returnTestAndDesign()
														.get(players.get(loop).getPosition()).getPoorEmployeeCost());

												System.out.println(
														"your new balance is : " + players.get(loop).getBalance());
												Board.returnTestAndDesign().get(players.get(loop).getPosition())
														.setOwnPooremployees(true);
												;
											}
											validinput = true;

										} else if (hireEmployees.equalsIgnoreCase("n")) {
											System.out.println("No problem ");
											validinput = true;
										} else {
											System.out.println("Please enter y or n only ");
											validinput = false;
										}
									}
								} while (!validinput);

							} catch (Exception ie) {
								System.out.println("Something went wrong ");
								developAreas(players, landed, loop, scanner);

							}

						} else if ((Board.returnTestAndDesign().get(players.get(loop).getPosition())
								.isOwnPooremployees())
								&& !(Board.returnTestAndDesign().get(players.get(loop).getPosition())
										.isOwnMediocoreemployees())
								&& !(Board.returnTestAndDesign().get(players.get(loop).getPosition())
										.isOwnGoodemployees())
								&& !(Board.returnTestAndDesign().get(players.get(loop).getPosition())
										.isOwnExceptionalemployees())) {
							System.out.println(" Mediocore employees cost " + Board.returnTestAndDesign()
									.get(players.get(loop).getPosition()).getMediocoreEmployeeCost());
							System.out.println("this increases the rent on this area to "
									+ (Board.returnTestAndDesign().get(players.get(loop).getPosition()).calculateRent()
											+ Board.returnTestAndDesign().get(players.get(loop).getPosition())
													.getMediocoreEmployeeRent()));
							System.out.println(
									" would you like to hire Medicore employees to develop your area? please enter y for yes or n for no followed by the enter key");
							try {

								do {
									if (scanner.hasNext()) {
										hireEmployees = scanner.next();
										if (hireEmployees.equalsIgnoreCase("y")) {
											if (players.get(loop).getBalance() < Board.returnTestAndDesign()
													.get(players.get(loop).getPosition()).getMediocoreEmployeeCost()) {
												System.out.println("insufficient funds  to pruchase employees");

											} else if (players.get(loop).getBalance() > Board.returnTestAndDesign()
													.get(players.get(loop).getPosition()).getMediocoreEmployeeCost()) {
												players.get(loop)
														.SubtractFromBalance(Board.returnTestAndDesign()
																.get(players.get(loop).getPosition())
																.getMediocoreEmployeeCost());
												Board.returnTestAndDesign().get(players.get(loop).getPosition())
														.setOwnMediocoreemployees(true);
												System.out.println(
														"your new balance is : " + players.get(loop).getBalance());
											}
											validinput = true;
										} else if (hireEmployees.equalsIgnoreCase("n")) {
											System.out.println("No problem ");
											validinput = true;
										} else {
											System.out.println("Please enter y or n only ");
											validinput = false;
										}
									}
								} while (!validinput);

							} catch (Exception ie) {
								System.out.println("Something went wrong ");
								developAreas(players, landed, loop, scanner);

							}

						} else if ((Board.returnTestAndDesign().get(players.get(loop).getPosition())
								.isOwnPooremployees())
								&& (Board.returnTestAndDesign().get(players.get(loop).getPosition())
										.isOwnMediocoreemployees())
								&& !(Board.returnTestAndDesign().get(players.get(loop).getPosition())
										.isOwnGoodemployees())
								&& !(Board.returnTestAndDesign().get(players.get(loop).getPosition())
										.isOwnExceptionalemployees())) {
							System.out.println(" Good employees cost " + Board.returnTestAndDesign()
									.get(players.get(loop).getPosition()).getGoodEmployeeCost());
							System.out.println("this increases the rent on this area to "
									+ (Board.returnTestAndDesign().get(players.get(loop).getPosition()).calculateRent()
											+ Board.returnTestAndDesign().get(players.get(loop).getPosition())
													.getGoodEmployeeRent()));
							System.out.println(
									" would you like to hire good employees to develop your area? please enter y for yes or n for no followed by the enter key");
							try {

								do {
									if (scanner.hasNext()) {
										hireEmployees = scanner.next();
										if (hireEmployees.equalsIgnoreCase("y")) {
											if (players.get(loop).getBalance() < Board.returnTestAndDesign()
													.get(players.get(loop).getPosition()).getGoodEmployeeCost()) {
												System.out.println("insufficient funds  to pruchase employees");

											} else if (players.get(loop).getBalance() > Board.returnTestAndDesign()
													.get(players.get(loop).getPosition()).getGoodEmployeeCost()) {
												players.get(loop).SubtractFromBalance(Board.returnTestAndDesign()
														.get(players.get(loop).getPosition()).getGoodEmployeeCost());
												Board.returnTestAndDesign().get(players.get(loop).getPosition())
														.setOwnGoodemployees(true);
												System.out.println(
														"your new balance is : " + players.get(loop).getBalance());
											}
											validinput = true;
										} else if (hireEmployees.equalsIgnoreCase("n")) {
											System.out.println("No problem ");
											validinput = true;
										} else {
											System.out.println("Please enter y or n only ");
											validinput = false;
										}
									}
								} while (!validinput);

							} catch (Exception ie) {
								System.out.println("Something went wrong ");
								developAreas(players, landed, loop, scanner);

							}
						} else if ((Board.returnTestAndDesign().get(players.get(loop).getPosition())
								.isOwnPooremployees())
								&& (Board.returnTestAndDesign().get(players.get(loop).getPosition())
										.isOwnMediocoreemployees())
								&& (Board.returnTestAndDesign().get(players.get(loop).getPosition())
										.isOwnGoodemployees())
								&& !(Board.returnTestAndDesign().get(players.get(loop).getPosition())
										.isOwnExceptionalemployees())) {
							System.out.println(" Exceptional employees cost " + Board.returnTestAndDesign()
									.get(players.get(loop).getPosition()).getExceptionalEmployeeCost());
							System.out.println("this increases the rent on this area to "
									+ (Board.returnTestAndDesign().get(players.get(loop).getPosition()).calculateRent()
											+ Board.returnTestAndDesign().get(players.get(loop).getPosition())
													.getExceptionalEmployeeRent()));
							System.out.println(
									" would you like to hire Exceptional employees to develop your area? please enter y for yes or n for no followed by the enter key");
							try {

								do {
									if (scanner.hasNext()) {
										hireEmployees = scanner.next();
										if (hireEmployees.equalsIgnoreCase("y")) {
											if (players.get(loop).getBalance() < Board.returnTestAndDesign()
													.get(players.get(loop).getPosition())
													.getExceptionalEmployeeCost()) {
												System.out.println("insufficient funds  to pruchase employees");

											} else if (players.get(loop).getBalance() > Board.returnTestAndDesign()
													.get(players.get(loop).getPosition())
													.getExceptionalEmployeeCost()) {
												players.get(loop)
														.SubtractFromBalance(Board.returnTestAndDesign()
																.get(players.get(loop).getPosition())
																.getExceptionalEmployeeCost());
												Board.returnTestAndDesign().get(players.get(loop).getPosition())
														.setOwnExceptionalemployees(true);
												System.out.println(
														"your new balance is : " + players.get(loop).getBalance());
											}
											validinput = true;
										} else if (hireEmployees.equalsIgnoreCase("n")) {
											System.out.println("No problem ");
											validinput = true;
										} else {
											System.out.println("Please enter y or n only ");
											validinput = false;
										}
									}
								} while (!validinput);

							} catch (Exception ie) {
								System.out.println("Something went wrong ");
								developAreas(players, landed, loop, scanner);

							}

						} else if ((Board.returnTestAndDesign().get(players.get(loop).getPosition())
								.isOwnPooremployees())
								&& (Board.returnTestAndDesign().get(players.get(loop).getPosition())
										.isOwnMediocoreemployees())
								&& (Board.returnTestAndDesign().get(players.get(loop).getPosition())
										.isOwnGoodemployees())
								&& (Board.returnTestAndDesign().get(players.get(loop).getPosition())
										.isOwnExceptionalemployees())) {
							System.out.println(
									"This area is fully developed you are recieveing the maximum rent possible");
						}
						correctInput = true;
					} else if (develop.equalsIgnoreCase("n")) {
						System.out.println("No problem");
						correctInput = true;
					} else {
						System.out.println("Please enter either y or n ");
						correctInput = false;
					}
				} while (!correctInput);
			}
			break;

		case DEVELOPMENT:

			for (int count = 0; count < players.get(loop).getPropertiesOwned().size(); count++) {

				if (Board.returnDev().containsKey(players.get(loop).getPropertiesOwned().get(count).getPosition())) {
					devPropertiesOwned += 1;
				} else {

				}

			}

			if (devPropertiesOwned == Board.returnDev().size()) {
				do {
					System.out.println(

							" You own all of the properties in the admin group, Would you like to hire staff in this area? Enter y for yet or N for no followed by the enter key ");

					develop = scanner.next();

					if (develop.equalsIgnoreCase("y")) {

						if (!(Board.returnDev().get(players.get(loop).getPosition()).isOwnPooremployees())
								&& !(Board.returnDev().get(players.get(loop).getPosition()).isOwnMediocoreemployees())
								&& !(Board.returnDev().get(players.get(loop).getPosition()).isOwnGoodemployees())
								&& !(Board.returnDev().get(players.get(loop).getPosition())
										.isOwnExceptionalemployees())) {
							System.out.println(" poor employees cost "
									+ Board.returnDev().get(players.get(loop).getPosition()).getPoorEmployeeCost());
							System.out.println("this increases the rent on this area to "
									+ (Board.returnDev().get(players.get(loop).getPosition()).calculateRent() + Board
											.returnDev().get(players.get(loop).getPosition()).getPoorEmployeeRent()));
							System.out.println(
									" would you like to hire poor employees to develop your area? please enter y for yes or n for no followed by the enter key");

							try {

								do {
									if (scanner.hasNext()) {
										hireEmployees = scanner.next();

										if (hireEmployees.equalsIgnoreCase("y")) {
											if (players.get(loop).getBalance() < Board.returnDev()
													.get(players.get(loop).getPosition()).getPoorEmployeeCost()) {
												System.out.println("insufficient funds  to pruchase employees");

											} else if (players.get(loop).getBalance() > Board.returnDev()
													.get(players.get(loop).getPosition()).getPoorEmployeeCost()) {

												players.get(loop).SubtractFromBalance(Board.returnDev()
														.get(players.get(loop).getPosition()).getPoorEmployeeCost());

												System.out.println(
														"your new balance is : " + players.get(loop).getBalance());
												Board.returnDev().get(players.get(loop).getPosition())
														.setOwnPooremployees(true);
												;
											}
											validinput = true;

										} else if (hireEmployees.equalsIgnoreCase("n")) {
											System.out.println("No problem ");
											validinput = true;
										} else {
											System.out.println("Please enter y or n only ");
											validinput = false;
										}
									}
								} while (!validinput);

							} catch (Exception ie) {
								System.out.println("Something went wrong ");
								developAreas(players, landed, loop, scanner);

							}

						} else if ((Board.returnDev().get(players.get(loop).getPosition()).isOwnPooremployees())
								&& !(Board.returnDev().get(players.get(loop).getPosition()).isOwnMediocoreemployees())
								&& !(Board.returnDev().get(players.get(loop).getPosition()).isOwnGoodemployees())
								&& !(Board.returnDev().get(players.get(loop).getPosition())
										.isOwnExceptionalemployees())) {
							System.out.println(" Mediocore employees cost " + Board.returnDev()
									.get(players.get(loop).getPosition()).getMediocoreEmployeeCost());
							System.out.println("this increases the rent on this area to "
									+ (Board.returnDev().get(players.get(loop).getPosition()).calculateRent()
											+ Board.returnDev().get(players.get(loop).getPosition())
													.getMediocoreEmployeeRent()));
							System.out.println(
									" would you like to hire Medicore employees to develop your area? please enter y for yes or n for no followed by the enter key");
							try {

								do {
									if (scanner.hasNext()) {
										hireEmployees = scanner.next();
										if (hireEmployees.equalsIgnoreCase("y")) {
											if (players.get(loop).getBalance() < Board.returnDev()
													.get(players.get(loop).getPosition()).getMediocoreEmployeeCost()) {
												System.out.println("insufficient funds  to pruchase employees");

											} else if (players.get(loop).getBalance() > Board.returnDev()
													.get(players.get(loop).getPosition()).getMediocoreEmployeeCost()) {
												players.get(loop).SubtractFromBalance(
														Board.returnDev().get(players.get(loop).getPosition())
																.getMediocoreEmployeeCost());
												Board.returnDev().get(players.get(loop).getPosition())
														.setOwnMediocoreemployees(true);
												System.out.println(
														"your new balance is : " + players.get(loop).getBalance());
											}
											validinput = true;
										} else if (hireEmployees.equalsIgnoreCase("n")) {
											System.out.println("No problem ");
											validinput = true;
										} else {
											System.out.println("Please enter y or n only ");
											validinput = false;
										}
									}
								} while (!validinput);

							} catch (Exception ie) {
								System.out.println("Something went wrong ");
								developAreas(players, landed, loop, scanner);

							}

						} else if ((Board.returnDev().get(players.get(loop).getPosition()).isOwnPooremployees())
								&& (Board.returnDev().get(players.get(loop).getPosition()).isOwnMediocoreemployees())
								&& !(Board.returnDev().get(players.get(loop).getPosition()).isOwnGoodemployees())
								&& !(Board.returnDev().get(players.get(loop).getPosition())
										.isOwnExceptionalemployees())) {
							System.out.println(" Good employees cost "
									+ Board.returnDev().get(players.get(loop).getPosition()).getGoodEmployeeCost());
							System.out.println("this increases the rent on this area to "
									+ (Board.returnDev().get(players.get(loop).getPosition()).calculateRent() + Board
											.returnDev().get(players.get(loop).getPosition()).getGoodEmployeeRent()));
							System.out.println(
									" would you like to hire good employees to develop your area? please enter y for yes or n for no followed by the enter key");
							try {

								do {
									if (scanner.hasNext()) {
										hireEmployees = scanner.next();
										if (hireEmployees.equalsIgnoreCase("y")) {
											if (players.get(loop).getBalance() < Board.returnDev()
													.get(players.get(loop).getPosition()).getGoodEmployeeCost()) {
												System.out.println("insufficient funds  to pruchase employees");

											} else if (players.get(loop).getBalance() > Board.returnDev()
													.get(players.get(loop).getPosition()).getGoodEmployeeCost()) {
												players.get(loop).SubtractFromBalance(Board.returnDev()
														.get(players.get(loop).getPosition()).getGoodEmployeeCost());
												Board.returnDev().get(players.get(loop).getPosition())
														.setOwnGoodemployees(true);
												System.out.println(
														"your new balance is : " + players.get(loop).getBalance());
											}
											validinput = true;
										} else if (hireEmployees.equalsIgnoreCase("n")) {
											System.out.println("No problem ");
											validinput = true;
										} else {
											System.out.println("Please enter y or n only ");
											validinput = false;
										}
									}
								} while (!validinput);

							} catch (Exception ie) {
								System.out.println("Something went wrong ");
								developAreas(players, landed, loop, scanner);

							}
						} else if ((Board.returnDev().get(players.get(loop).getPosition()).isOwnPooremployees())
								&& (Board.returnDev().get(players.get(loop).getPosition()).isOwnMediocoreemployees())
								&& (Board.returnDev().get(players.get(loop).getPosition()).isOwnGoodemployees())
								&& !(Board.returnDev().get(players.get(loop).getPosition())
										.isOwnExceptionalemployees())) {
							System.out.println(" Exceptional employees cost " + Board.returnDev()
									.get(players.get(loop).getPosition()).getExceptionalEmployeeCost());
							System.out.println("this increases the rent on this area to "
									+ (Board.returnDev().get(players.get(loop).getPosition()).calculateRent()
											+ Board.returnDev().get(players.get(loop).getPosition())
													.getExceptionalEmployeeRent()));
							System.out.println(
									" would you like to hire Exceptional employees to develop your area? please enter y for yes or n for no followed by the enter key");
							try {

								do {
									if (scanner.hasNext()) {
										hireEmployees = scanner.next();
										if (hireEmployees.equalsIgnoreCase("y")) {
											if (players.get(loop).getBalance() < Board.returnDev()
													.get(players.get(loop).getPosition())
													.getExceptionalEmployeeCost()) {
												System.out.println("insufficient funds  to pruchase employees");

											} else if (players.get(loop).getBalance() > Board.returnDev()
													.get(players.get(loop).getPosition())
													.getExceptionalEmployeeCost()) {
												players.get(loop).SubtractFromBalance(
														Board.returnDev().get(players.get(loop).getPosition())
																.getExceptionalEmployeeCost());
												Board.returnDev().get(players.get(loop).getPosition())
														.setOwnExceptionalemployees(true);
												System.out.println(
														"your new balance is : " + players.get(loop).getBalance());
											}
											validinput = true;
										} else if (hireEmployees.equalsIgnoreCase("n")) {
											System.out.println("No problem ");
											validinput = true;
										} else {
											System.out.println("Please enter y or n only ");
											validinput = false;
										}
									}
								} while (!validinput);

							} catch (Exception ie) {
								System.out.println("Something went wrong ");
								developAreas(players, landed, loop, scanner);

							}

						} else if ((Board.returnDev().get(players.get(loop).getPosition()).isOwnPooremployees())
								&& (Board.returnDev().get(players.get(loop).getPosition()).isOwnMediocoreemployees())
								&& (Board.returnDev().get(players.get(loop).getPosition()).isOwnGoodemployees())
								&& (Board.returnDev().get(players.get(loop).getPosition())
										.isOwnExceptionalemployees())) {
							System.out.println(
									"This area is fully developed you are recieveing the maximum rent possible");
						}
						correctInput = true;
					} else if (develop.equalsIgnoreCase("n")) {
						System.out.println("No problem");
						correctInput = true;
					} else {
						System.out.println("Please enter either y or n ");
						correctInput = false;
					}
				} while (!correctInput);
			}
			break;

		case PROGRAMMING:

			for (int count = 0; count < players.get(loop).getPropertiesOwned().size(); count++) {

				if (Board.returnProgramming()
						.containsKey(players.get(loop).getPropertiesOwned().get(count).getPosition())) {
					ProgrammingPropertiesOwned += 1;
				} else {

				}

			}

			if (ProgrammingPropertiesOwned == Board.returnProgramming().size()) {
				do {
					System.out.println(

							" You own all of the properties in the admin group, Would you like to hire staff in this area? Enter y for yet or N for no followed by the enter key ");

					develop = scanner.next();

					if (develop.equalsIgnoreCase("y")) {

						if (!(Board.returnProgramming().get(players.get(loop).getPosition()).isOwnPooremployees())
								&& !(Board.returnProgramming().get(players.get(loop).getPosition())
										.isOwnMediocoreemployees())
								&& !(Board.returnProgramming().get(players.get(loop).getPosition())
										.isOwnGoodemployees())
								&& !(Board.returnProgramming().get(players.get(loop).getPosition())
										.isOwnExceptionalemployees())) {
							System.out.println(" poor employees cost " + Board.returnProgramming()
									.get(players.get(loop).getPosition()).getPoorEmployeeCost());
							System.out.println("this increases the rent on this area to "
									+ (Board.returnProgramming().get(players.get(loop).getPosition()).calculateRent()
											+ Board.returnProgramming().get(players.get(loop).getPosition())
													.getPoorEmployeeRent()));
							System.out.println(
									" would you like to hire poor employees to develop your area? please enter y for yes or n for no followed by the enter key");

							try {

								do {
									if (scanner.hasNext()) {
										hireEmployees = scanner.next();

										if (hireEmployees.equalsIgnoreCase("y")) {
											if (players.get(loop).getBalance() < Board.returnProgramming()
													.get(players.get(loop).getPosition()).getPoorEmployeeCost()) {
												System.out.println("insufficient funds  to pruchase employees");

											} else if (players.get(loop).getBalance() > Board.returnProgramming()
													.get(players.get(loop).getPosition()).getPoorEmployeeCost()) {

												players.get(loop).SubtractFromBalance(Board.returnProgramming()
														.get(players.get(loop).getPosition()).getPoorEmployeeCost());

												System.out.println(
														"your new balance is : " + players.get(loop).getBalance());
												Board.returnProgramming().get(players.get(loop).getPosition())
														.setOwnPooremployees(true);
												;
											}
											validinput = true;

										} else if (hireEmployees.equalsIgnoreCase("n")) {
											System.out.println("No problem ");
											validinput = true;
										} else {
											System.out.println("Please enter y or n only ");
											validinput = false;
										}
									}
								} while (!validinput);

							} catch (Exception ie) {
								System.out.println("Something went wrong ");
								developAreas(players, landed, loop, scanner);

							}

						} else if ((Board.returnProgramming().get(players.get(loop).getPosition()).isOwnPooremployees())
								&& !(Board.returnProgramming().get(players.get(loop).getPosition())
										.isOwnMediocoreemployees())
								&& !(Board.returnProgramming().get(players.get(loop).getPosition())
										.isOwnGoodemployees())
								&& !(Board.returnProgramming().get(players.get(loop).getPosition())
										.isOwnExceptionalemployees())) {
							System.out.println(" Mediocore employees cost " + Board.returnProgramming()
									.get(players.get(loop).getPosition()).getMediocoreEmployeeCost());
							System.out.println("this increases the rent on this area to "
									+ (Board.returnProgramming().get(players.get(loop).getPosition()).calculateRent()
											+ Board.returnProgramming().get(players.get(loop).getPosition())
													.getMediocoreEmployeeRent()));
							System.out.println(
									" would you like to hire Medicore employees to develop your area? please enter y for yes or n for no followed by the enter key");
							try {

								do {
									if (scanner.hasNext()) {
										hireEmployees = scanner.next();
										if (hireEmployees.equalsIgnoreCase("y")) {
											if (players.get(loop).getBalance() < Board.returnProgramming()
													.get(players.get(loop).getPosition()).getMediocoreEmployeeCost()) {
												System.out.println("insufficient funds  to pruchase employees");

											} else if (players.get(loop).getBalance() > Board.returnProgramming()
													.get(players.get(loop).getPosition()).getMediocoreEmployeeCost()) {
												players.get(loop)
														.SubtractFromBalance(Board.returnProgramming()
																.get(players.get(loop).getPosition())
																.getMediocoreEmployeeCost());
												Board.returnProgramming().get(players.get(loop).getPosition())
														.setOwnMediocoreemployees(true);
												System.out.println(
														"your new balance is : " + players.get(loop).getBalance());
											}
											validinput = true;
										} else if (hireEmployees.equalsIgnoreCase("n")) {
											System.out.println("No problem ");
											validinput = true;
										} else {
											System.out.println("Please enter y or n only ");
											validinput = false;
										}
									}
								} while (!validinput);

							} catch (Exception ie) {
								System.out.println("Something went wrong ");
								developAreas(players, landed, loop, scanner);

							}

						} else if ((Board.returnProgramming().get(players.get(loop).getPosition()).isOwnPooremployees())
								&& (Board.returnProgramming().get(players.get(loop).getPosition())
										.isOwnMediocoreemployees())
								&& !(Board.returnProgramming().get(players.get(loop).getPosition())
										.isOwnGoodemployees())
								&& !(Board.returnProgramming().get(players.get(loop).getPosition())
										.isOwnExceptionalemployees())) {
							System.out.println(" Good employees cost " + Board.returnProgramming()
									.get(players.get(loop).getPosition()).getGoodEmployeeCost());
							System.out.println("this increases the rent on this area to "
									+ (Board.returnProgramming().get(players.get(loop).getPosition()).calculateRent()
											+ Board.returnProgramming().get(players.get(loop).getPosition())
													.getGoodEmployeeRent()));
							System.out.println(
									" would you like to hire good employees to develop your area? please enter y for yes or n for no followed by the enter key");
							try {

								do {
									if (scanner.hasNext()) {
										hireEmployees = scanner.next();
										if (hireEmployees.equalsIgnoreCase("y")) {
											if (players.get(loop).getBalance() < Board.returnProgramming()
													.get(players.get(loop).getPosition()).getGoodEmployeeCost()) {
												System.out.println("insufficient funds  to pruchase employees");

											} else if (players.get(loop).getBalance() > Board.returnProgramming()
													.get(players.get(loop).getPosition()).getGoodEmployeeCost()) {
												players.get(loop).SubtractFromBalance(Board.returnProgramming()
														.get(players.get(loop).getPosition()).getGoodEmployeeCost());
												Board.returnProgramming().get(players.get(loop).getPosition())
														.setOwnGoodemployees(true);
												System.out.println(
														"your new balance is : " + players.get(loop).getBalance());
											}
											validinput = true;
										} else if (hireEmployees.equalsIgnoreCase("n")) {
											System.out.println("No problem ");
											validinput = true;
										} else {
											System.out.println("Please enter y or n only ");
											validinput = false;
										}
									}
								} while (!validinput);

							} catch (Exception ie) {
								System.out.println("Something went wrong ");
								developAreas(players, landed, loop, scanner);

							}
						} else if ((Board.returnProgramming().get(players.get(loop).getPosition()).isOwnPooremployees())
								&& (Board.returnProgramming().get(players.get(loop).getPosition())
										.isOwnMediocoreemployees())
								&& (Board.returnProgramming().get(players.get(loop).getPosition()).isOwnGoodemployees())
								&& !(Board.returnProgramming().get(players.get(loop).getPosition())
										.isOwnExceptionalemployees())) {
							System.out.println(" Exceptional employees cost " + Board.returnProgramming()
									.get(players.get(loop).getPosition()).getExceptionalEmployeeCost());
							System.out.println("this increases the rent on this area to "
									+ (Board.returnProgramming().get(players.get(loop).getPosition()).calculateRent()
											+ Board.returnProgramming().get(players.get(loop).getPosition())
													.getExceptionalEmployeeRent()));
							System.out.println(
									" would you like to hire Exceptional employees to develop your area? please enter y for yes or n for no followed by the enter key");
							try {

								do {
									if (scanner.hasNext()) {
										hireEmployees = scanner.next();
										if (hireEmployees.equalsIgnoreCase("y")) {
											if (players.get(loop).getBalance() < Board.returnProgramming()
													.get(players.get(loop).getPosition())
													.getExceptionalEmployeeCost()) {
												System.out.println("insufficient funds  to pruchase employees");

											} else if (players.get(loop).getBalance() > Board.returnProgramming()
													.get(players.get(loop).getPosition())
													.getExceptionalEmployeeCost()) {
												players.get(loop)
														.SubtractFromBalance(Board.returnProgramming()
																.get(players.get(loop).getPosition())
																.getExceptionalEmployeeCost());
												Board.returnProgramming().get(players.get(loop).getPosition())
														.setOwnExceptionalemployees(true);
												System.out.println(
														"your new balance is : " + players.get(loop).getBalance());
											}
											validinput = true;
										} else if (hireEmployees.equalsIgnoreCase("n")) {
											System.out.println("No problem ");
											validinput = true;
										} else {
											System.out.println("Please enter y or n only ");
											validinput = false;
										}
									}
								} while (!validinput);

							} catch (Exception ie) {
								System.out.println("Something went wrong ");
								developAreas(players, landed, loop, scanner);

							}

						} else if ((Board.returnProgramming().get(players.get(loop).getPosition()).isOwnPooremployees())
								&& (Board.returnProgramming().get(players.get(loop).getPosition())
										.isOwnMediocoreemployees())
								&& (Board.returnProgramming().get(players.get(loop).getPosition()).isOwnGoodemployees())
								&& (Board.returnProgramming().get(players.get(loop).getPosition())
										.isOwnExceptionalemployees())) {
							System.out.println(
									"This area is fully developed you are recieveing the maximum rent possible");
						}
						correctInput = true;
					} else if (develop.equalsIgnoreCase("n")) {
						System.out.println("No problem");
						correctInput = true;
					} else {
						System.out.println("Please enter either y or n ");
						correctInput = false;
					}
				} while (!correctInput);
			}
			break;

		default:

			break;
		}

	}

}
