/**
 * 
 */
package gameSystem;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

import board.Board;
import board.GoSquare;
import player.Player;

//import player.Player;

/**
 * @author dearb
 *
 */
public class Turn {

	public static final String PAGE_BREAK = "---------------------------------";
	public static final String newTurn = "\n \n ";
	// Create die
	private static Die die = new Die();

	/**
	 * public static void main(String[] args) { Scanner scanner = new
	 * Scanner(System.in); Board.main(args); takeTurn(createPlayerArray(), scanner);
	 * 
	 * scanner.close(); }
	 */
	 /** public static ArrayList<Player> createPlayerArray() { ArrayList<Player>
	  players = new ArrayList<Player>(); Player p1 = new Player();
	  p1.setName("Player1"); p1.setBalance(200);
	  
	  Player p2 = new Player(); p2.setName("Player2"); p2.setBalance(10);
	  
	  players.add(p1); players.add(p2); return players; }
	 */
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		ArrayList<player.Player> players = player.PlayerManager.returnPlayerArray();
		//takeTurn(createPlayerArray(), scanner);
		
		Board.main(args);
	//	turnLoop(players, scanner);
		takeTurn(players,scanner);
	}
	/**
	 * method to retain the players turn in the event of an error, calls the playerTurn class 
	 * @param players
	 * @param scanner
	 * @return
	 */
public static int turnLoop(ArrayList<player.Player> players, Scanner scanner) {
	int playerTurn = 0;
	for (int loop = 0; loop < players.size(); loop++) {
		takeTurn(players, scanner);
		playerTurn=loop;
	}
	return playerTurn;
	
	
}
	/**
	 * manages the players turns and options within those turns, calls the other
	 * methods as appropriate
	 * 
	 * @param players
	 * @param scanner
	 */
	public static void takeTurn(ArrayList<player.Player> players, Scanner scanner) {
		Scanner playerTurn = new Scanner(System.in);

		int landed;

		boolean EndRound = false;

		System.out.println(PAGE_BREAK);

		do {
			for (int loop = 0; loop < players.size(); loop++) {

			
				System.out.println(newTurn + "Player " + (loop + 1) + "  " + players.get(loop).getName()
						+ ",type the number of what you would like to do and press enter");
				System.out.println("1 Roll ");
				System.out.println("2 View Balance ");
				System.out.println("3 View Properties owned ");
				System.out.println("4 View Board");
				System.out.println("5 Quit");

				int ready;
				try {
					if (playerTurn.hasNext()) {
						
						do {
							ready = playerTurn.nextInt();

							if (ready == 5) {
								boolean validInput;
								do {
								System.out.println("Quiting will end the game for all players, are you sure you want to quit? \n enter y for yes or n for no");
								String ConfirmQuit=scanner.next();
									if (ConfirmQuit.equalsIgnoreCase("y")) {
										quitGame(players);
										EndRound = true;
										validInput= true;
								}else if(ConfirmQuit.equalsIgnoreCase("n")) {
									EndRound = false;
									validInput=true;
								}else {
									System.out.println("Please enter y or n only ");
									validInput=false;
								}
								}while(!validInput);
								

							} else if (ready == 2) {

								System.out.println("Your balance is : " + players.get(loop).getBalance());

							} else if (ready == 3) {

								players.get(loop).PrintAllProperties();

							} else if (ready == 4) {
								displayeBoard();

							} else if (ready == 1) {
								landed = playersTurn(players, loop);
								displayLandedPositionInfo(landed);
								BuyOrRent.hasOwnerCheck(landed, loop, scanner, players);
								Development.developAreas(players, landed, loop, scanner);
								EndRound = false;
							} else {
								System.out.println(" please enter a number between 1- 5 only");
							}

						} while (!(ready == 1));

					} else {
						System.out.println("Please enetr a valid number between 1 and 5");
						
					}
				} catch (InputMismatchException ime) {
					System.out.println("Error please enter whole numbers only ");
					takeTurn(players, scanner);
					
				}
			}

		} while (!EndRound);
		playerTurn.close();
		
}

	/**
	 * rolls the dice to calculate the position of the player
	 * 
	 * @param players
	 * @param loop
	 * @return
	 */
	public static int playersTurn(ArrayList<player.Player> players, int loop) {
		int rolled = 0;
		// calls rollDie method
		rolled = die.rollDie();

		// outputs result of die roll
		System.out.println("You've rolled a " + rolled);

		// gets current position of player on the board
		int currentPosition = players.get(loop).getPosition();
		int landed;

		int potentialPosition = currentPosition + rolled;

		// maintains the new position within the positions on the board
		if (potentialPosition > Board.returnBoard().size()) {
			landed = (potentialPosition - (Board.returnBoard().size()));
			players.get(loop).setPosition(landed);

			// calls passGo method from Go class to add to player's balance
			GoSquare.passGo(players, loop);
		} else {
			landed = potentialPosition;

			players.get(loop).setPosition(landed);

		}
		return landed;
	}

	/**
	 * prints the players position to screen
	 * 
	 * @param landed
	 */
	public static void displayLandedPositionInfo(int landed) {
		System.out.println("You have landed on...");
		Board.returnBoard().get(landed).displayAll();

	}

	/**
	 * prints the board to screen
	 */
	public static void displayeBoard() {
		for (int loop = 1; loop < Board.returnBoard().size(); loop++) {
			System.out.println(Board.returnBoard().get(loop).getPosition() + " \t NAME: "
					+ Board.returnBoard().get(loop).getName() + " \t AREA: " + Board.returnBoard().get(loop).getType()
					+ "\t VALUE: " + Board.returnBoard().get(loop).getValue());
			
			switch ( Board.returnBoard().get(loop).getType()) {
			case  ADMIN:
				System.out.print("\t Already Purchased : "+Board.returnAdmin().get(loop).isHasOwner());
				System.out.println();
				break;
			case TESTING_AND_DESIGN:
				System.out.print("\t Already Purchased : "+Board.returnTestAndDesign().get(loop).isHasOwner());
				System.out.println();
				break;
			case DEVELOPMENT:
				System.out.print("\t Already Purchased : "+Board.returnDev().get(loop).isHasOwner());
				System.out.println();
				break;
			case PROGRAMMING:
				System.out.print("\t Already Purchased : "+Board.returnProgramming().get(loop).isHasOwner());
				System.out.println();
				break;
				default:
					break;
			}
		}
	}

	/**
	 * quits the game and calls the declare winner method
	 * 
	 * @param players
	 */

	public static void quitGame(ArrayList<player.Player> players) {

		System.out.println("You have quit the game - Game over");
		System.out.println(PAGE_BREAK);
		System.out.println("Final Balances");

		decideWinner(players);

		System.exit(0);

	}

	/**
	 * method to calculate the toatl value of the players property and current
	 * balance and declare the winner
	 * 
	 * @param players
	 */
	public static void decideWinner(ArrayList<player.Player> players) {
		
		// ends the game if player has chosen to do so

		for (int count = 0; count < players.size(); count++) {
			players.get(count).displayAll(); 
			for (int innerCount = 0; innerCount < players.get(count).getPropertiesOwned().size(); innerCount++) {
				players.get(count).addToBalance(players.get(count).getPropertiesOwned().get(innerCount).getValue());

			}
			System.out.println(
					"Player " + (count + 1) + " adjusted final balance is : " + players.get(count).getBalance());
			System.out.println(newTurn);
		}

		Player highestBalance= null;
		
		
		for (int outercount = 0; outercount < players.size(); outercount++) {
			
			for (Player p: players) {
				if (highestBalance == null) {
					highestBalance= p;
				}else if(p.getBalance()>highestBalance.getBalance()) {
					highestBalance= p;
				}else if (p.getBalance()==highestBalance.getBalance()) {
					if (p.getName()==highestBalance.getName()) {
						
					}else {
						System.out.println("It's a Tie! "+ p.getName()+" and "+highestBalance.getName()+" have drawn");
					}
					
				}
				
				
			}
		
		
		}
		System.out.println(newTurn);
		System.out.println("The winner is : " + highestBalance.getName() );
		System.out.println(newTurn);
	}



	

}