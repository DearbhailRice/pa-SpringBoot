/**
 * 
 */
package gameSystem;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

import board.Area;
import board.Board;
import player.Player;

/**
 * @author dearb
 *
 */
public class BuyOrRent {
	public static final String newTurn = "\n \n ";

	/**
	 * method to allow players to purchase area which are not already owned
	 * 
	 * @param players
	 * @param landed
	 * @param loop
	 * @param scanner
	 */
	public static void buyArea(ArrayList<player.Player> players, int landed, int loop, Scanner scanner) {

		Player player = new Player();
		System.out.println("your balance is : " + players.get(loop).getBalance());
		System.out.println(newTurn);
		System.out.println("Would you like to purchase this area? enter y or n");
		try {
			if (scanner.hasNext()) {

				String response = scanner.next();
				if (response.equalsIgnoreCase("y")) {
					if (players.get(loop).getBalance() > Board.returnBoard().get(landed).getValue()) {
						players.get(loop).SubtractFromBalance(Board.returnBoard().get(landed).getValue());
						System.out.println(newTurn);
						System.out.println("Congratulations you now own " + Board.returnBoard().get(landed).getName());
						player = players.get(loop);
						Area property = new Area();

						switch (Board.returnBoard().get(landed).getType()) {

						case ADMIN:
							Board.returnAdmin().get(landed).setOwner(player);
							players.get(loop).getPropertiesOwned()
									.ensureCapacity(players.get(loop).getPropertiesOwned().size() + 1);
							property = Board.returnAdmin().get(landed);
							players.get(loop).getPropertiesOwned().add(property);
							Board.returnAdmin().get(landed).setHasOwner(true);
							;
							break;

						case TESTING_AND_DESIGN:
							Board.returnTestAndDesign().get(landed).setOwner(player);
							players.get(loop).getPropertiesOwned()
									.ensureCapacity(players.get(loop).getPropertiesOwned().size() + 1);
							property = Board.returnTestAndDesign().get(landed);
							players.get(loop).getPropertiesOwned().add(property);
							Board.returnTestAndDesign().get(landed).setHasOwner(true);

							break;

						case DEVELOPMENT:
							Board.returnDev().get(landed).setOwner(player);
							players.get(loop).getPropertiesOwned()
									.ensureCapacity(players.get(loop).getPropertiesOwned().size() + 1);
							property = Board.returnDev().get(landed);
							players.get(loop).getPropertiesOwned().add(property);
							Board.returnDev().get(landed).setHasOwner(true);
							break;

						case PROGRAMMING:
							Board.returnProgramming().get(landed).setOwner(player);
							players.get(loop).getPropertiesOwned()
									.ensureCapacity(players.get(loop).getPropertiesOwned().size() + 1);
							property = Board.returnProgramming().get(landed);
							players.get(loop).getPropertiesOwned().add(property);
							Board.returnProgramming().get(landed).setHasOwner(true);
							break;

						default:
							break;
						}
					} else {
						System.out.println(" you have insufficient funds to complete transaction ");
					}
					players.get(loop).displayAll();
				}else if (response.equalsIgnoreCase("n")){
					System.out.println("no problem");
				} else {
				System.out.println(" plaese enter either a y or n");
				buyArea(players, landed, loop, scanner);
			}
			}
		} catch (InputMismatchException ime) {
			System.out.println("please eneter y or n only ");
			buyArea(players, landed, loop, scanner);
		}
	}

	public static void hasOwnerCheck(int landed, int loop, Scanner scanner, ArrayList<Player> players) {
		if ((Board.returnBoard().get(landed).isPurchase())) {
			switch (Board.returnBoard().get(landed).getType()) {
			case ADMIN:
				if (!Board.returnAdmin().get(landed).isHasOwner()) {
					buyArea(players, landed, loop, scanner);
				} else {
					if (Board.returnAdmin().get(landed).getOwner() == players.get(loop)) {
						System.out.println(" You own " + Board.returnAdmin().get(landed).getName());
					}
					
					 else {
						 System.out.println(" you have landed on an area which "
									+ Board.returnAdmin().get(landed).getOwner().getName() + " ownes ");
						System.out.println(" you owe " + Board.returnAdmin().get(landed).calculateRent());
						System.out.println("Your balanc is : " + players.get(loop).getBalance());
						if ((players.get(loop).getBalance()) > (Board.returnAdmin().get(landed).calculateRent())) {
							System.out.println("Rent Owed : " + Board.returnAdmin().get(landed).calculateRent());
							players.get(loop).SubtractFromBalance(Board.returnAdmin().get(landed).calculateRent());

							Board.returnAdmin().get(landed).getOwner()
									.addToBalance(Board.returnAdmin().get(landed).calculateRent());

							System.out.println(players.get(loop).getName() + " Your new balance is : "
									+ players.get(loop).getBalance());
							System.out.println(
									Board.returnAdmin().get(landed).getOwner().getName() + " Your new balance is : "
											+ Board.returnAdmin().get(landed).getOwner().getBalance());
						} else {
							System.out.println("you have insuffent funds to pay rent, therefore you are bankrupt");
							Turn.quitGame(players);
						}

					}
				}
				break;
			case TESTING_AND_DESIGN:
				if (!Board.returnTestAndDesign().get(landed).isHasOwner()) {
					buyArea(players, landed, loop, scanner);
				} else {

					System.out.println(" you have landed on an area which "
							+ Board.returnTestAndDesign().get(landed).getOwner().getName() + " ownes ");
					if (Board.returnTestAndDesign().get(landed).getOwner() == players.get(loop)) {
						System.out.println(" You own " + Board.returnTestAndDesign().get(landed).getName());
					} else {
						System.out.println(" you owe " + Board.returnTestAndDesign().get(landed).calculateRent());
						System.out.println("Your balanc is : " + players.get(loop).getBalance());
						if ((players.get(loop).getBalance()) > (Board.returnTestAndDesign().get(landed)
								.calculateRent())) {
							System.out
									.println("Rent Owed : " + Board.returnTestAndDesign().get(landed).calculateRent());
							players.get(loop)
									.SubtractFromBalance(Board.returnTestAndDesign().get(landed).calculateRent());

							Board.returnTestAndDesign().get(landed).getOwner()
									.addToBalance(Board.returnTestAndDesign().get(landed).calculateRent());

							System.out.println(players.get(loop).getName() + " Your new balance is : "
									+ players.get(loop).getBalance());
							System.out.println(Board.returnTestAndDesign().get(landed).getOwner().getName()
									+ " Your new balance is : "
									+ Board.returnTestAndDesign().get(landed).getOwner().getBalance());
						} else {
							System.out.println("you have insuffent funds to pay rent, therefore you are bankrupt");
							Turn.quitGame(players);
						}

					}
				}
				break;
			case DEVELOPMENT:
				if (!Board.returnDev().get(landed).isHasOwner()) {
					buyArea(players, landed, loop, scanner);
				} else {

					System.out.println(" you have landed on an area which "
							+ Board.returnDev().get(landed).getOwner().getName() + " ownes ");
					if (Board.returnDev().get(landed).getOwner() == players.get(loop)) {
						System.out.println(" You own " + Board.returnDev().get(landed).getName());
					} else {
						System.out.println(" you owe " + Board.returnDev().get(landed).calculateRent());
						System.out.println("Your balanc is : " + players.get(loop).getBalance());
						if ((players.get(loop).getBalance()) > (Board.returnDev().get(landed).calculateRent())) {
							System.out.println("Rent Owed : " + Board.returnDev().get(landed).calculateRent());
							players.get(loop).SubtractFromBalance(Board.returnDev().get(landed).calculateRent());

							Board.returnDev().get(landed).getOwner()
									.addToBalance(Board.returnDev().get(landed).calculateRent());

							System.out.println(players.get(loop).getName() + " Your new balance is : "
									+ players.get(loop).getBalance());
							System.out.println(
									Board.returnDev().get(landed).getOwner().getName() + " Your new balance is : "
											+ Board.returnDev().get(landed).getOwner().getBalance());
						} else {
							System.out.println("you have insuffent funds to pay rent, therefore you are bankrupt");
							Turn.quitGame(players);
						}

					}
				}
				break;
			case PROGRAMMING:
				if (!Board.returnProgramming().get(landed).isHasOwner()) {
					buyArea(players, landed, loop, scanner);
				} else {

					System.out.println(" you have landed on an area which "
							+ Board.returnProgramming().get(landed).getOwner().getName() + " ownes ");
					if (Board.returnProgramming().get(landed).getOwner() == players.get(loop)) {
						System.out.println(" You own " + Board.returnProgramming().get(landed).getName());
					} else {
						System.out.println(" you owe " + Board.returnProgramming().get(landed).calculateRent());
						System.out.println("Your balanc is : " + players.get(loop).getBalance());
						if ((players.get(loop).getBalance()) > (Board.returnProgramming().get(landed).calculateRent())) {
							System.out.println("Rent Owed : " + Board.returnProgramming().get(landed).calculateRent());
							players.get(loop).SubtractFromBalance(Board.returnProgramming().get(landed).calculateRent());

							Board.returnProgramming().get(landed).getOwner()
									.addToBalance(Board.returnProgramming().get(landed).calculateRent());

							System.out.println(players.get(loop).getName() + " Your new balance is : "
									+ players.get(loop).getBalance());
							System.out.println(
									Board.returnProgramming().get(landed).getOwner().getName() + " Your new balance is : "
											+ Board.returnProgramming().get(landed).getOwner().getBalance());
						} else {
							System.out.println("you have insuffent funds to pay rent, therefore you are bankrupt");
							Turn.quitGame(players);
						}

					}
				}

				break;

			default:
				break;

			}

		}
	}

}
