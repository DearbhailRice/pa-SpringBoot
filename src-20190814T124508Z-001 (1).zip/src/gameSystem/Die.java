package gameSystem;
/**
 * 
 */

	import java.util.Random;

	/**
	 * Die class - allows creation of die object 
	 * @author jamesmcauley
	 *
	 */

	public class Die {
		
		/**
		 * Default constructor for die
		 */
		public Die() {
			
		}
		
		/**
		 * rollDie method simulates rolling two die using a random number generator
		 * @return roll - outcome of the die roll, integer in range 1-6
		 */
		public int rollDie() {
			
			// Set up random number generator for dice roll
			Random dieRoll = new Random();

			//First dice
			int roll1 = (dieRoll.nextInt(4) + 1);
			//Second dice 
			int roll2 = (dieRoll.nextInt(4) + 1);
		
			return roll1 + roll2;

		}
		
		

	
}
