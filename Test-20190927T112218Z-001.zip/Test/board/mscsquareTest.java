/**
 * 
 */
package board;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;


/**
 * @author dearb
 *
 */
public class mscsquareTest {
	
	 Type validType;
	 
	 boolean validBool;
	
	int validNumLow;
	int validNumHigh;
	int validPosition;
	String validName;
	
	
	  
	 int invalidNumLow;
	 int invalidNumHigh;
	 
	  mscSquare square = new mscSquare();

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		
		validPosition = 16;
		 
		 validType= Type.ADMIN;
		 validBool= true;
		
		validName = "ValidName";
		
		 validNumHigh= 200;
		 validNumLow= 1;
		 
		 invalidNumHigh=201;
		 invalidNumLow= -10;
	}

	/**
	 * Test method for {@link board.mscSquare#mscSquare()}.
	 */
	@Test
	public void testMscSquareDefaultConstructor() {
		mscSquare s = new mscSquare();
		assertNotNull(s);
	}

	/**
	 * Test method for {@link board.mscSquare#mscSquare(java.lang.String, board.Type, int, int, boolean, boolean)}.
	 */
	@Test
	public void testMscSquareConstructorwithArgs() {
		//StringTypeIntIntBooleanBoolean
		mscSquare s = new mscSquare(validName,validType,validPosition,validNumHigh,validBool,validBool);
		assertEquals(validName, s.getName());
		assertEquals(validType, s.getType());
		assertEquals(validPosition, s.getPosition());
		assertEquals(validNumHigh, s.getValue());
		assertEquals(validBool, s.isPurchase());
		assertEquals(validBool, s.isGoToJail());
		
	}

	/**
	 * Test method for {@link board.mscSquare#setGoToJail(boolean)}.
	 */
	@Test
	public void testSetGoToJail() {
		square.setGoToJail(validBool);
		assertEquals(validBool, square.isGoToJail());
	}

}
