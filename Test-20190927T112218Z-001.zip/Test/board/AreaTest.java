/**
 * 
 */
package board;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import player.Player;

/**
 * @author dearb
 *
 */
public class AreaTest {

	
	 Type validType;
	 
	 boolean validBool;
	
	 
	Player player = new Player();
	Area area = new Area();
	int validNumLow;
	int validNumHigh;
	int validPosition;
	String validName;
	  Player validowner;
	
	  
	 int invalidNumLow;
	 int invalidNumHigh;
	  Player invalidowner;
	
	  
	
	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		validPosition = 16;
		 
		 validType= Type.ADMIN;
		 validBool= true;
		
		validName = "ValidName";
		
		 validNumHigh= 200;
		 validNumLow= 1;
		 
		 invalidNumHigh=201;
		 invalidNumLow= -10;
		   
	}

	/**
	 * Test method for {@link board.Area#Area()}.
	 */
	@Test
	public void testAreaDefaultConstructor () {
		Area a = new Area();
		assertNotNull(a);
	}

	/**
	 * Test method for {@link board.Area#Area(java.lang.String, board.Type, int, int, boolean, int, int, int, int, int, int, int, int, int, int)}.
	 */
	@Test
	public void testAreaConstructorWithoutBools() {
		//StringTypeIntIntBooleanIntIntIntIntIntIntIntIntIntInt()
		/* String name, Type type, int position, int value, boolean purchase, int propertyValue, int baseRent,
			int poorEmployeeCost, int poorEmployeeRent, int mediocoreEmployeeCost, int mediocoreEmployeeRent,
			int goodEmployeeCost, int goodEmployeeRent, int exceptionalEmployeeCost, int exceptionalEmployeeRent
		 */
		
		Area a = new Area (validName,validType,validPosition,validNumLow, validBool,validNumLow,validNumLow,validNumLow,validNumLow,validNumLow,validNumLow,validNumLow,validNumLow,validNumLow,validNumLow);
		assertEquals(validName, a.getName());
		assertEquals(validType, a.getType());
		assertEquals(validNumLow, a.getValue());
		assertEquals(validBool, a.isPurchase());
		assertEquals(validNumLow, a.getPropertyValue());
		assertEquals(validNumLow, a.getBaseRent());
		assertEquals(validPosition, a.getPosition());
		assertEquals(validNumLow, a.getPoorEmployeeCost());
		assertEquals(validNumLow, a.getPoorEmployeeRent());
		assertEquals(validNumLow, a.getMediocoreEmployeeCost());
		assertEquals(validNumLow, a.getMediocoreEmployeeRent());
		assertEquals(validNumLow, a.getGoodEmployeeCost());
		assertEquals(validNumLow, a.getGoodEmployeeRent());
		assertEquals(validNumLow, a.getExceptionalEmployeeCost());
		assertEquals(validNumLow, a.getExceptionalEmployeeRent());
		
		
	}

	/**
	 * Test method for {@link board.Area#Area(java.lang.String, board.Type, int, int, boolean, int, int, int, int, int, int, int, int, int, int, player.Player, boolean, boolean, boolean, boolean, boolean)}.
	 */
	@Test
	public void testAreaConstructWithAllArgs() {
		/* String name, Type type, int position, int value, boolean purchase, int propertyValue, int baseRent,
			int poorEmployeeCost, int poorEmployeeRent, int mediocoreEmployeeCost, int mediocoreEmployeeRent,
			int goodEmployeeCost, int goodEmployeeRent, int exceptionalEmployeeCost, int exceptionalEmployeeRent,
			Player owner, boolean hasOwner, boolean ownPooremployees, boolean ownMediocoreemployees,
			boolean ownGoodemployees, boolean ownExceptionalemployees
		 */
		Area a = new Area (validName,validType,validNumLow,validNumLow, validBool,validNumLow,validNumLow,validNumLow,validNumLow,validNumLow,validNumLow,validNumLow,validNumLow,validNumLow,validNumLow,player, validBool,validBool,validBool,validBool,validBool);
		assertEquals(validName, a.getName());
		assertEquals(validType, a.getType());
		assertEquals(validNumLow, a.getBaseRent());
		assertEquals(validBool, a.isPurchase());
		assertEquals(validNumLow, a.getPoorEmployeeCost());
		assertEquals(validNumLow, a.getPoorEmployeeRent());
		assertEquals(validNumLow, a.getGoodEmployeeCost());
		assertEquals(validNumLow, a.getGoodEmployeeRent());
		assertEquals(validNumLow, a.getMediocoreEmployeeCost());
		assertEquals(validNumLow, a.getMediocoreEmployeeRent());
		assertEquals(validNumLow, a.getExceptionalEmployeeCost());
		assertEquals(validNumLow, a.getExceptionalEmployeeRent());
		assertEquals(validNumLow, a.getValue());
		assertEquals(validNumLow, a.getPropertyValue());
		assertEquals(player, a.getOwner());
		assertEquals(validBool, a.isHasOwner());
		assertEquals(validBool, a.isOwnPooremployees());
		assertEquals(validBool, a.isOwnMediocoreemployees());
		assertEquals(validBool, a.isOwnGoodemployees());
		assertEquals(validBool, a.isOwnExceptionalemployees());
	}

	/**
	 * Test method for {@link board.Area#setPropertyValue(int)}.
	 */
	@Test
	public void testgetSetPropertyValue() {
		area.setPropertyValue(validNumHigh);
		assertEquals(validNumHigh, area.getPropertyValue());
	}
	
	/*
	 * test invalid method
	 */
	@Test (expected= IllegalArgumentException.class)
	public void testgetSetPropertyValueInvalid() {
		area.setPropertyValue(invalidNumLow);
		
	}

	/**
	 * Test method for {@link board.Area#setBaseRent(int)}.
	 */
	@Test
	public void testgetSetBaseRent() {
		area.setBaseRent(validNumHigh);
		assertEquals(validNumHigh, area.getBaseRent());
	}
	/*
	 * test invalid method
	 */
	@Test (expected= IllegalArgumentException.class)
	public void testgetSetBaseRentInvalid() {
		area.setBaseRent(invalidNumLow);
		
	}

	/**
	 * Test method for {@link board.Area#setPoorEmployeeCost(int)}.
	 */
	@Test
	public void testgetSetPoorEmployeeCost() {
		area.setPoorEmployeeCost(validNumHigh);
		assertEquals(validNumHigh, area.getPoorEmployeeCost());
	}
	
	/*
	 * test invalid method
	 */
	@Test (expected= IllegalArgumentException.class)
	public void testgetSetPoorEmployeeCostInvalid() {
		area.setPoorEmployeeCost(invalidNumLow);
		
	}

	/**
	 * Test method for {@link board.Area#setPoorEmployeeRent(int)}.
	 */
	@Test
	public void testgetSetPoorEmployeeRent() {
		area.setPoorEmployeeRent(validNumHigh);
		assertEquals(validNumHigh, area.getPoorEmployeeRent());
	}
	
	/*
	 * test invalid method
	 */
	@Test (expected= IllegalArgumentException.class)
	public void testgetSetPoorEmployeeRentInvalid() {
		area.setPoorEmployeeRent(invalidNumLow);
		
	}

	/**
	 * Test method for {@link board.Area#setMediocoreEmployeeCost(int)}.
	 */
	@Test
	public void testSetMediocoreEmployeeCost() {
		area.setMediocoreEmployeeCost(validNumHigh);
		assertEquals(validNumHigh, area.getMediocoreEmployeeCost());
	}

	/*
	 * test invalid method
	 */
	@Test (expected= IllegalArgumentException.class)
	public void testSetMediocoreEmployeeCostInvalid() {
		area.setMediocoreEmployeeCost(invalidNumLow);
		
	}
	
	/**
	 * Test method for {@link board.Area#setMediocoreEmployeeRent(int)}.
	 */
	@Test
	public void testSetMediocoreEmployeeRent() {
		area.setMediocoreEmployeeRent(validNumHigh);
		assertEquals(validNumHigh, area.getMediocoreEmployeeRent());
	}
	
	/*
	 * test invalid method
	 */
	@Test (expected= IllegalArgumentException.class)
	public void testSetMediocoreEmployeeRentInvalid() {
		area.setMediocoreEmployeeRent(invalidNumLow);
		
	}

	/**
	 * Test method for {@link board.Area#setGoodEmployeeCost(int)}.
	 */
	@Test
	public void testSetGoodEmployeeCost() {
		area.setGoodEmployeeCost(validNumHigh);
		assertEquals(validNumHigh, area.getGoodEmployeeCost());
	}

	/*
	 * test invalid method
	 */
	@Test (expected= IllegalArgumentException.class)
	public void testSetGoodEmployeeCostInvalid() {
		area.setGoodEmployeeCost(invalidNumLow);
		
	}
	/**
	 * Test method for {@link board.Area#setGoodEmployeeRent(int)}.
	 */
	@Test
	public void testSetGoodEmployeeRent() {
		area.setGoodEmployeeRent(validNumHigh);
		assertEquals(validNumHigh, area.getGoodEmployeeRent());
	}

	/*
	 * test invalid method
	 */
	@Test (expected= IllegalArgumentException.class)
	public void testSetGoodEmployeeRentInvalid() {
		area.setGoodEmployeeRent(invalidNumLow);
		
	}
	/**
	 * Test method for {@link board.Area#setExceptionalEmployeeCost(int)}.
	 */
	@Test
	public void testSetExceptionalEmployeeCost() {
		area.setExceptionalEmployeeCost(validNumHigh);
		assertEquals(validNumHigh, area.getExceptionalEmployeeCost());
	}
	

	/*
	 * test invalid method
	 */
	@Test (expected= IllegalArgumentException.class)
	public void testSetExceptionalEmployeeCostInvalid() {
		area.setExceptionalEmployeeCost(invalidNumLow);
		
	}

	/**
	 * Test method for {@link board.Area#setExceptionalEmployeeRent(int)}.
	 */
	@Test
	public void testSetExceptionalEmployeeRent() {
		area.setExceptionalEmployeeRent(validNumHigh);
		assertEquals(validNumHigh, area.getExceptionalEmployeeRent());
	}
	/*
	 * test invalid method
	 */
	@Test (expected= IllegalArgumentException.class)
	public void testSetExceptionalEmployeeRentInvalid() {
		area.setExceptionalEmployeeRent(invalidNumLow);
		
	}

	/**
	 * Test method for {@link board.Area#setOwner(player.Player)}.
	 */
	@Test
	public void testSetOwner() {
		area.setOwner(player);
		assertEquals(player, area.getOwner());
	}

	/**
	 * Test method for {@link board.Area#setOwnPooremployees(boolean)}.
	 */
	@Test
	public void testSetOwnPooremployees() {
		area.setOwnPooremployees(validBool);
		assertEquals(validBool, area.isOwnPooremployees());
	}

	/**
	 * Test method for {@link board.Area#setOwnMediocoreemployees(boolean)}.
	 */
	@Test
	public void testSetOwnMediocoreemployees() {
		area.setOwnMediocoreemployees(validBool);
		assertEquals(validBool, area.isOwnMediocoreemployees());
	}

	/**
	 * Test method for {@link board.Area#setOwnGoodemployees(boolean)}.
	 */
	@Test
	public void testSetOwnGoodemployees() {
		area.setOwnGoodemployees(validBool);
		assertEquals(validBool, area.isOwnGoodemployees());
	}

	/**
	 * Test method for {@link board.Area#setOwnExceptionalemployees(boolean)}.
	 */
	@Test
	public void testSetOwnExceptionalemployees() {
		area.setOwnExceptionalemployees(validBool);
		assertEquals(validBool, area.isOwnExceptionalemployees());
	}

	/**
	 * Test method for {@link board.Area#setHasOwner(boolean)}.
	 */
	@Test
	public void testSetHasOwner() {
		area.setHasOwner(validBool);
		assertEquals(validBool, area.isHasOwner());
	}

	/**
	 * Test method for {@link board.Area#calculateRent()}.
	 */
	@Test
	public void testCalculateRent() {
		area.setBaseRent(validNumHigh);
		area.setMediocoreEmployeeRent(validNumHigh);
		area.setPoorEmployeeRent(validNumHigh);
		area.setGoodEmployeeRent(validNumHigh);
		area.setExceptionalEmployeeRent(validNumHigh);
		area.setHasOwner(validBool);
		area.setOwnGoodemployees(validBool);
		area.setOwnPooremployees(validBool);
		area.setOwnMediocoreemployees(validBool);
		area.setOwnExceptionalemployees(validBool);
		int total = (area.getBaseRent()+area.getExceptionalEmployeeRent()+area.getGoodEmployeeRent()+area.getMediocoreEmployeeRent()+area.getPoorEmployeeRent());
		
		assertEquals(total, area.calculateRent());
	}

}
