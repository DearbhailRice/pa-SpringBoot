/**
 * 
 */
package board;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import player.Player;



/**
 * @author dearb
 *
 */
public class GoSquareTest {
	
	
	 Type validType;
	 
	 boolean validBool;
		int initalbalance;
		int passGo;
	int validNumLow;
	int validNumHigh;
	int validPosition;
	String validName;
	  
	Player player = new Player();
	  
	 int invalidNumLow;
	 int invalidNumHigh;

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		passGo=50;
		initalbalance=player.getBalance();
		validPosition = 16;
		 
		 validType= Type.ADMIN;
		 validBool= true;
		
		validName = "ValidName";
		
		 validNumHigh= 200;
		 validNumLow= 1;
		 
		 invalidNumHigh=201;
		 invalidNumLow= -10;
	}

	/**
	 * Test method for {@link board.GoSquare#GoSquare()}.
	 */
	@Test
	public void testGoSquaredefaultconstructor() {
		GoSquare g = new GoSquare();
		assertNotNull(g);
	}

	/**
	 * Test method for {@link board.GoSquare#GoSquare(java.lang.String, board.Type, int, int, boolean)}.
	 */
	@Test
	public void testGoSquare() {
		//StringTypeIntIntBoolean
		GoSquare g = new GoSquare(validName,validType,validPosition,validNumLow,validBool);
		assertEquals(validName, g.getName());
		assertEquals(validType, g.getType());
		assertEquals(validPosition, g.getPosition());
		assertEquals(validNumLow,g.getValue());
		assertEquals(validBool, g.isPurchase());
	}

	/**
	 * Test method for {@link board.GoSquare#passGo(java.util.ArrayList, int)}.
	 */
	@Test
	public void testPassGo() {
		player.addToBalance(passGo);
		
		
		assertEquals(initalbalance+passGo, player.getBalance());
		
	}

}
