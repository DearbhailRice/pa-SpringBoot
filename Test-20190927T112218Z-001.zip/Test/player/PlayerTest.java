/**
 * 
 */
package player;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;

import board.Area;

/**
 * @author dearb
 *
 */
public class PlayerTest {
	
	//global data 
	
	Player player = new Player();
	
	String nameValid, nameInvalidshort, nameInvalidLong, nameInvalidNull;
	
	int balanceValid, balanceValid0,balanceInvalidNull, balanceInvalid, positionValidhigh, positionValidLow, positionInvalidLow, positionInvalidHigh;
	ArrayList <board.Area> propertiesOwned = new ArrayList <board.Area>();
	Area testArea = new Area();
	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		nameValid="name Name";
		nameInvalidshort="pl";
		nameInvalidLong="nameisInvalidis31characterslong"; //31characters
		nameInvalidNull=null;
		
		balanceValid=200;
		balanceValid0=0;
		balanceInvalid= -1;
		positionValidhigh=16;
		positionValidLow=1;
		positionInvalidLow=0;
		positionInvalidHigh=17;
		
		
		 
	}

	/**
	 * Test method for {@link player.Player#Player(java.lang.String, int)}.
	 */
	@Test
	public void testPlayerDefaultConstructor() {
		Player play = new Player();
		assertNotNull(play);
	}
	
	/**
	 * Test method for {@link player.Player#Player(java.lang.String, int)}.
	 */
	@Test
	public void testPlayertConstructorwithargs() {
		Player play = new Player(nameValid, balanceValid,positionValidLow);
		
		assertEquals(nameValid, play.getName());
		assertEquals(balanceValid, play.getBalance());
		assertEquals(positionValidLow, play.getPosition());
	}

	/**
	 * Test method for {@link player.Player#setName(java.lang.String)}.
	 */
	@Test
	public void testSetgetNamevalid() {
		player.setName(nameValid);
		assertEquals(nameValid, player.getName());
	}
	
	/**
	 * Test method for {@link player.Player#setName(java.lang.String)}.
	 */
	@Test (expected= IllegalArgumentException.class)
	public void testSetgetNameInvalidNull() {
		
		player.setName(nameInvalidNull);
	}
	
	/**
	 * Test method for {@link player.Player#setName(java.lang.String)}.
	 */
	@Test (expected= IllegalArgumentException.class)
	public void testSetgetNameInvalidLong() {
		
		player.setName(nameInvalidLong);
	}
	
	/**
	 * Test method for {@link player.Player#setName(java.lang.String)}.
	 */
	@Test (expected= IllegalArgumentException.class)
	public void testSetgetNameInvalidShort() {
		
		player.setName(nameInvalidshort);
	}
	
	
	

	/**
	 * Test method for {@link player.Player#setBalance(int)}.
	 */
	@Test
	public void testSetgetBalanceValid() {
		player.setBalance(balanceValid);
		assertEquals(balanceValid, player.getBalance());
	}
	

	/**
	 * Test method for {@link player.Player#setBalance(int)}.
	 */
	@Test
	public void testSetgetBalanceValid0() {
		player.setBalance(balanceValid0);
		assertEquals(balanceValid0, player.getBalance());
	}
	/**
	 * Test method for {@link player.Player#setBalance(int)}.
	 */
	@Test(expected = IllegalArgumentException.class)
	public void testSetgetBalanceInvalid() {
		player.setBalance(balanceInvalid);
		
	}
	
	/**
	 * Test method for {@link player.Player#setPosition(int)}.
	 */
	@Test
	public void testSetgetpositionValidLow() {
		player.setPosition(positionValidLow);
		assertEquals(positionValidLow, player.getPosition());
	}
	
	/**
	 * Test method for {@link player.Player#setPosition(int)}.
	 */
	@Test
	public void testSetgetpositionValidHigh() {
		player.setPosition(positionValidhigh);
		assertEquals(positionValidhigh, player.getPosition());
	}
	
	
	/**
	 * Test method for {@link player.Player#setPosition(int)}.
	 */
	@Test(expected = IllegalArgumentException.class)
	public void testSetgetPositionInvalidlow() {
		player.setPosition(positionInvalidLow);
		
	}
	
	/**
	 * Test method for {@link player.Player#setPosition(int)}.
	 */
	@Test(expected = IllegalArgumentException.class)
	public void testSetgetPositionInvalidHigh() {
		player.setPosition(positionInvalidHigh);
		
	}
	
	/**
	 * 
	 */
	@Test
	public void testPlayerArray() {
		propertiesOwned.add(testArea);
		assertEquals(propertiesOwned.get(0), testArea);
	
	}
}
